package com.example

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.*
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        enableEdgeToEdge()
        setContent {
            val viewModel: ExamBridgeViewModel = viewModel()
            val isDark by viewModel.isDarkMode.collectAsState()
            val userProfileState by viewModel.userProfile.collectAsState(initial = null)

            MyApplicationTheme(darkTheme = isDark) {
                // Main Entrance
                val screenState by viewModel.currentScreen.collectAsState()

                when (screenState) {
                    is Screen.Splash -> SplashScreen(isDark)
                    is Screen.Onboarding -> OnboardingScreen(viewModel, isDark)
                    is Screen.Auth -> AuthScreen(viewModel, isDark)
                    is Screen.StreamSelect -> StreamSelectScreen(viewModel, isDark)
                    else -> {
                        // User Authenticated Layout (with Hamburguer Navigation Drawer)
                        userProfileState?.let { profile ->
                            AuthenticatedAppLayout(viewModel, profile, isDark, screenState)
                        } ?: Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AuthenticatedAppLayout(
    viewModel: ExamBridgeViewModel,
    profile: UserProfile,
    isDark: Boolean,
    screen: Screen
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val isDrawerOpen by viewModel.isDrawerOpen.collectAsState()

    // Sync state-based drawer trigger with standard Compose DrawerState
    LaunchedEffect(isDrawerOpen) {
        if (isDrawerOpen) {
            drawerState.open()
        } else {
            drawerState.close()
        }
    }

    LaunchedEffect(drawerState.currentValue) {
        if (drawerState.isClosed) {
            viewModel.isDrawerOpen.value = false
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = if (isDark) MaterialTheme.colorScheme.background else Color.White,
                modifier = Modifier.width(300.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Drawer Header Profile Card
                    Column {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = profile.name.take(2).uppercase(),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = profile.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = if (isDark) Color.White else Color.Black
                        )
                        Text(
                            text = profile.email,
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "S.ID: ${profile.studentId}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.tertiary
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Divider()
                        Spacer(modifier = Modifier.height(20.dp))

                        // Drawer Navigation links
                        val menuItems = listOf(
                            Triple("Language", Icons.Default.Language, Screen.Settings),
                            Triple("Analytics & Stats", Icons.Default.BarChart, Screen.Analytics),
                            Triple("About App", Icons.Default.Info, Screen.Settings),
                            Triple("Rate Us", Icons.Default.ThumbUp, Screen.Settings),
                            Triple("Settings", Icons.Default.Settings, Screen.Settings),
                            Triple("Admin Panel", Icons.Default.AdminPanelSettings, Screen.AdminDashboard)
                        )

                        menuItems.forEach { (label, icon, targetScreen) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (targetScreen is Screen.Dashboard) {
                                            viewModel.setDashboardTab(0)
                                        } else {
                                            viewModel.navigateTo(targetScreen)
                                        }
                                        scope.launch { drawerState.close() }
                                    }
                                    .padding(vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(icon, label, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(16.dp))
                                Text(
                                    text = label,
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 15.sp,
                                    color = if (isDark) Color.White else Color.Black
                                )
                            }
                        }
                    }

                    // Logout Drawer bottom action
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                scope.launch { drawerState.close() }
                                viewModel.logout()
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ExitToApp, "Logout", tint = Color.Red, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = "Log Out Account",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.Red
                        )
                    }
                }
            }
        }
    ) {
        // Main Screen Router
        Box(modifier = Modifier.fillMaxSize()) {
            when (screen) {
                is Screen.Dashboard -> MainDashboardView(viewModel, profile, isDark)
                is Screen.Practice -> PracticeScreen(viewModel, isDark)
                is Screen.MockCenter -> MockCenterScreen(viewModel, isDark)
                is Screen.Analytics -> AnalyticsScreen(viewModel, isDark)
                is Screen.Videos -> VideosScreen(viewModel, isDark)
                is Screen.Leaderboard -> LeaderboardScreen(viewModel, isDark)
                is Screen.PremiumUpgrade -> PremiumUpgradeScreen(viewModel, profile, isDark)
                is Screen.Settings -> SettingsScreen(viewModel, profile, isDark)
                is Screen.Profile -> ProfileScreen(viewModel, profile, isDark)
                is Screen.AdminDashboard -> AdminDashboardScreen(viewModel, isDark)
                else -> MainDashboardView(viewModel, profile, isDark)
            }
        }
    }
}
