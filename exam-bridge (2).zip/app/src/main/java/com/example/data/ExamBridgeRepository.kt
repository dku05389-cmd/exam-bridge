package com.example.data

import kotlinx.coroutines.flow.Flow

class ExamBridgeRepository(private val db: ExamBridgeDatabase) {

    // DAOs
    private val userProfileDao = db.userProfileDao()
    private val questionDao = db.questionDao()
    private val mockExamResultDao = db.mockExamResultDao()
    private val premiumRequestDao = db.premiumRequestDao()
    private val offlineDownloadDao = db.offlineDownloadDao()

    // --- User Profile ---
    fun getUserProfileFlow(): Flow<UserProfile?> = userProfileDao.getUserProfileFlow()
    suspend fun getUserProfile(): UserProfile? = userProfileDao.getUserProfile()
    suspend fun insertOrUpdateProfile(profile: UserProfile) = userProfileDao.insertOrUpdateProfile(profile)
    suspend fun updateStream(studentId: String, stream: String) = userProfileDao.updateStream(studentId, stream)
    suspend fun updatePersonalInfo(studentId: String, name: String, school: String) = userProfileDao.updatePersonalInfo(studentId, name, school)
    suspend fun updatePremiumStatus(studentId: String, status: String) = userProfileDao.updatePremiumStatus(studentId, status)
    suspend fun updatePoints(studentId: String, points: Int) = userProfileDao.updatePoints(studentId, points)

    // --- Questions ---
    fun getAllQuestionsFlow(): Flow<List<Question>> = questionDao.getAllQuestionsFlow()
    fun getQuestionsByStreamFlow(stream: String): Flow<List<Question>> = questionDao.getQuestionsByStreamFlow(stream)
    fun getQuestionsBySubjectFlow(subject: String): Flow<List<Question>> = questionDao.getQuestionsBySubjectFlow(subject)
    fun getBookmarkedQuestionsFlow(): Flow<List<Question>> = questionDao.getBookmarkedQuestionsFlow()
    suspend fun insertQuestion(question: Question) = questionDao.insertQuestion(question)
    suspend fun insertQuestions(questions: List<Question>) = questionDao.insertQuestions(questions)
    suspend fun updateBookmarkStatus(id: Int, isBookmarked: Boolean) = questionDao.updateBookmarkStatus(id, isBookmarked)
    suspend fun updateSubjectDownloadStatus(subject: String, isDownloaded: Boolean) = questionDao.updateSubjectDownloadStatus(subject, isDownloaded)
    suspend fun deleteQuestionById(id: Int) = questionDao.deleteQuestionById(id)
    suspend fun deleteAllQuestions() = questionDao.deleteAllQuestions()

    // --- Mock Exam Results ---
    fun getAllResultsFlow(): Flow<List<MockExamResult>> = mockExamResultDao.getAllResultsFlow()
    suspend fun insertResult(result: MockExamResult) = mockExamResultDao.insertResult(result)

    // --- Premium Requests ---
    fun getRequestFlow(): Flow<PremiumRequest?> = premiumRequestDao.getRequestFlow()
    fun getAllRequestsFlow(): Flow<List<PremiumRequest>> = premiumRequestDao.getAllRequestsFlow()
    suspend fun insertRequest(request: PremiumRequest) = premiumRequestDao.insertRequest(request)
    suspend fun updateRequestStatus(studentId: String, status: String, comment: String) {
        premiumRequestDao.updateRequestStatus(studentId, status, comment)
        // Auto sync user premium status when admin changes status
        val currentProfile = getUserProfile()
        if (currentProfile != null && currentProfile.studentId == studentId) {
            updatePremiumStatus(studentId, status)
        }
    }
    suspend fun deleteRequest(studentId: String) = premiumRequestDao.deleteRequest(studentId)

    // --- Offline Downloads ---
    fun getAllDownloadsFlow(): Flow<List<OfflineDownload>> = offlineDownloadDao.getAllDownloadsFlow()
    suspend fun insertDownload(download: OfflineDownload) {
        offlineDownloadDao.insertDownload(download)
        updateSubjectDownloadStatus(download.title, true)
    }
    suspend fun deleteDownload(contentId: String, subjectName: String) {
        offlineDownloadDao.deleteDownload(contentId)
        updateSubjectDownloadStatus(subjectName, false)
    }
    suspend fun clearAllDownloads() {
        offlineDownloadDao.clearAllDownloads()
        // we can set all questions download state back to false
        // Since we are clearing all, we can do it via a query or in memory
    }
}
