package com.example.data

object QuestionSeeder {
    fun getSeedQuestions(): List<Question> {
        return listOf(
            // Biology (Natural)
            Question(
                subject = "Biology",
                topic = "Cell Biology",
                questionText = "Which organelle is known as the powerhouse of the cell, responsible for producing ATP?",
                optionA = "Chloroplast",
                optionB = "Mitochondria",
                optionC = "Ribosome",
                optionD = "Golgi Apparatus",
                correctAnswer = "B",
                explanation = "Mitochondria are double-membraned organelles that generate most of the cell's chemical energy in the form of adenosine triphosphate (ATP).",
                difficulty = "Easy",
                stream = "Natural"
            ),
            Question(
                subject = "Biology",
                topic = "Genetics",
                questionText = "In genetics, what is the term used to describe the physical or observable characteristics of an organism?",
                optionA = "Genotype",
                optionB = "Phenotype",
                optionC = "Allele",
                optionD = "Heterozygous",
                correctAnswer = "B",
                explanation = "Phenotype refers to the physical expression or traits of an organism, as determined by its genetic makeup (genotype) and environmental influences.",
                difficulty = "Medium",
                stream = "Natural"
            ),
            Question(
                subject = "Biology",
                topic = "Ecology",
                questionText = "Which trophic level do primary consumers typically occupy in an ecosystem's food chain?",
                optionA = "First Trophic Level (Producers)",
                optionB = "Second Trophic Level (Herbivores)",
                optionC = "Third Trophic Level (Carnivores)",
                optionD = "Fourth Trophic Level (Apex Predators)",
                correctAnswer = "B",
                explanation = "Primary consumers are herbivores that feed directly on producers (plants), placing them in the second trophic level.",
                difficulty = "Easy",
                stream = "Natural"
            ),

            // Physics (Natural)
            Question(
                subject = "Physics",
                topic = "Mechanics",
                questionText = "According to Newton's Second Law of Motion, the acceleration of an object is directly proportional to the net force acting on it and inversely proportional to its:",
                optionA = "Velocity",
                optionB = "Volume",
                optionC = "Mass",
                optionD = "Displacement",
                correctAnswer = "C",
                explanation = "Newton's Second Law is written as F = ma, which rearranges to a = F/m. Acceleration is inversely proportional to mass.",
                difficulty = "Easy",
                stream = "Natural"
            ),
            Question(
                subject = "Physics",
                topic = "Thermodynamics",
                questionText = "Which law of thermodynamics states that energy cannot be created or destroyed, only transformed from one form to another?",
                optionA = "Zeroth Law",
                optionB = "First Law",
                optionC = "Second Law",
                optionD = "Third Law",
                correctAnswer = "B",
                explanation = "The First Law of Thermodynamics is the law of conservation of energy: energy can change forms but total energy in a closed system remains constant.",
                difficulty = "Medium",
                stream = "Natural"
            ),

            // Chemistry (Natural)
            Question(
                subject = "Chemistry",
                topic = "Atomic Structure",
                questionText = "What is the maximum number of electrons that can occupy the outermost valence shell of an atom in the second period?",
                optionA = "2",
                optionB = "8",
                optionC = "18",
                optionD = "32",
                correctAnswer = "B",
                explanation = "According to the octet rule, the second energy level can hold a maximum of 8 electrons (2 in the s subshell and 6 in the p subshell).",
                difficulty = "Medium",
                stream = "Natural"
            ),
            Question(
                subject = "Chemistry",
                topic = "Chemical Bonding",
                questionText = "Which type of chemical bond is formed when two atoms share pairs of valence electrons?",
                optionA = "Ionic Bond",
                optionB = "Covalent Bond",
                optionC = "Metallic Bond",
                optionD = "Hydrogen Bond",
                correctAnswer = "B",
                explanation = "Covalent bonding involves the sharing of electrons between non-metal atoms to achieve stable noble gas electronic configurations.",
                difficulty = "Easy",
                stream = "Natural"
            ),

            // English (Both)
            Question(
                subject = "English",
                topic = "Grammar & Usage",
                questionText = "Select the option that correctly completes the sentence: 'By the time the professor arrived, the students ________ the classroom.'",
                optionA = "entered",
                optionB = "have entered",
                optionC = "had entered",
                optionD = "were entering",
                correctAnswer = "C",
                explanation = "We use the past perfect tense ('had entered') to describe an action that happened before another action in the past ('arrived').",
                difficulty = "Medium",
                stream = "Both"
            ),
            Question(
                subject = "English",
                topic = "Vocabulary",
                questionText = "What is the closest synonym for the word 'Meticulous'?",
                optionA = "Careless",
                optionB = "Extremely careful and precise",
                optionC = "Very fast",
                optionD = "Aggressive",
                correctAnswer = "B",
                explanation = "'Meticulous' means showing great attention to detail; very careful and precise.",
                difficulty = "Easy",
                stream = "Both"
            ),

            // Mathematics (Both - different content can be loaded)
            Question(
                subject = "Mathematics",
                topic = "Algebra",
                questionText = "Solve for x in the quadratic equation: x^2 - 5x + 6 = 0.",
                optionA = "x = 1 or x = 6",
                optionB = "x = 2 or x = 3",
                optionC = "x = -2 or x = -3",
                optionD = "x = 0 or x = 5",
                correctAnswer = "B",
                explanation = "Factoring the quadratic gives (x - 2)(x - 3) = 0. Therefore, x = 2 or x = 3.",
                difficulty = "Medium",
                stream = "Both"
            ),
            Question(
                subject = "Mathematics",
                topic = "Calculus",
                questionText = "What is the derivative of f(x) = 3x^3 - 5x + 12 with respect to x?",
                optionA = "9x^2 - 5",
                optionB = "3x^2 - 5",
                optionC = "9x^3 - 5x",
                optionD = "9x^2",
                correctAnswer = "A",
                explanation = "Using the power rule, d/dx(3x^3) = 9x^2, d/dx(-5x) = -5, and d/dx(12) = 0. Thus, f'(x) = 9x^2 - 5.",
                difficulty = "Medium",
                stream = "Both"
            ),

            // Aptitude (Both)
            Question(
                subject = "Aptitude",
                topic = "Logical Reasoning",
                questionText = "If all squares are rectangles, and all rectangles are polygons, then which of the following is logically certain?",
                optionA = "All polygons are squares.",
                optionB = "All squares are polygons.",
                optionC = "Some rectangles are not polygons.",
                optionD = "No squares are polygons.",
                correctAnswer = "B",
                explanation = "By syllogistic transitive logic: if A is inside B, and B is inside C, then A must be inside C. All squares are polygons.",
                difficulty = "Medium",
                stream = "Both"
            ),
            Question(
                subject = "Aptitude",
                topic = "Analytical Reasoning",
                questionText = "Complete the sequence: 3, 7, 15, 31, 63, ___",
                optionA = "125",
                optionB = "127",
                optionC = "129",
                optionD = "131",
                correctAnswer = "B",
                explanation = "The pattern is (Previous Number * 2) + 1. So, (63 * 2) + 1 = 126 + 1 = 127.",
                difficulty = "Medium",
                stream = "Both"
            ),

            // History (Social)
            Question(
                subject = "History",
                topic = "Ethiopian History",
                questionText = "Which Axumite King is famously known for adopting Christianity as the official state religion in the 4th century AD?",
                optionA = "King Kaleb",
                optionB = "King Ezana",
                optionC = "King Gebre Meskel",
                optionD = "King Armah",
                correctAnswer = "B",
                explanation = "King Ezana was the ruler of the Axumite Kingdom who converted to Christianity under the guidance of Frumentius, making Axum one of the earliest Christian states.",
                difficulty = "Medium",
                stream = "Social"
            ),
            Question(
                subject = "History",
                topic = "World History",
                questionText = "The Treaty of Versailles, signed in 1919, officially concluded which major global conflict?",
                optionA = "World War I",
                optionB = "World War II",
                optionC = "The Franco-Prussian War",
                optionD = "The Napoleonic Wars",
                correctAnswer = "A",
                explanation = "The Treaty of Versailles was the most important of the peace treaties that brought World War I to an end.",
                difficulty = "Easy",
                stream = "Social"
            ),

            // Geography (Social)
            Question(
                subject = "Geography",
                topic = "Physical Geography",
                questionText = "Which layer of the Earth's atmosphere lies directly above the troposphere and contains the protective ozone layer?",
                optionA = "Mesosphere",
                optionB = "Stratosphere",
                optionC = "Thermosphere",
                optionD = "Exosphere",
                correctAnswer = "B",
                explanation = "The stratosphere is the second major layer of Earth's atmosphere, just above the troposphere, and is home to the ozone layer.",
                difficulty = "Easy",
                stream = "Social"
            ),
            Question(
                subject = "Geography",
                topic = "Human Geography",
                questionText = "What is the term used to describe the movement of population from rural agricultural areas to urban cities?",
                optionA = "Industrialization",
                optionB = "Urbanization",
                optionC = "Migration",
                optionD = "Demographic Transition",
                correctAnswer = "B",
                explanation = "Urbanization refers to the population shift from rural to urban residency, the gradual increase in the proportion of people living in urban areas.",
                difficulty = "Easy",
                stream = "Social"
            ),

            // Economics (Social)
            Question(
                subject = "Economics",
                topic = "Microeconomics",
                questionText = "According to the Law of Demand, holding other factors constant, if the price of a good increases, what happens to the quantity demanded?",
                optionA = "It increases",
                optionB = "It decreases",
                optionC = "It remains completely unchanged",
                optionD = "It shifts the entire demand curve to the right",
                correctAnswer = "B",
                explanation = "The law of demand states that price and quantity demanded are inversely related; as price rises, consumers buy less.",
                difficulty = "Easy",
                stream = "Social"
            ),
            Question(
                subject = "Economics",
                topic = "Macroeconomics",
                questionText = "What is the primary indicator used to measure the total monetary or market value of all finished goods and services produced within a country's borders in a specific time period?",
                optionA = "Gross National Product (GNP)",
                optionB = "Gross Domestic Product (GDP)",
                optionC = "Consumer Price Index (CPI)",
                optionD = "Net National Income (NNI)",
                correctAnswer = "B",
                explanation = "Gross Domestic Product (GDP) is the standard measure of value added created through the production of goods and services in a country.",
                difficulty = "Medium",
                stream = "Social"
            )
        )
    }
}
