package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// ==========================================
// 1. Entities
// ==========================================

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val studentId: String, // unique: EB-SID-XXXXXX
    val name: String,
    val email: String,
    val phone: String,
    val school: String,
    val stream: String, // "Natural Science", "Social Science", "None"
    val isPremium: String, // "FREE", "PENDING", "PREMIUM"
    val registrationDate: String,
    val joinedDate: String,
    val referralLink: String,
    val points: Int,
    val streakDays: Int,
    val dailyGoalHours: Float,
    val avatarId: Int,
    val isNotificationsEnabled: Boolean = true,
    val language: String = "English" // "English", "Amharic", "Afaan Oromo", "Tigrinya"
)

@Entity(tableName = "questions")
data class Question(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subject: String,
    val topic: String,
    val questionText: String,
    val optionA: String,
    val optionB: String,
    val optionC: String,
    val optionD: String,
    val correctAnswer: String, // "A", "B", "C", "D"
    val explanation: String,
    val difficulty: String, // "Easy", "Medium", "Hard"
    val stream: String, // "Natural", "Social", "Both"
    val isBookmarked: Boolean = false,
    val isDownloaded: Boolean = false
)

@Entity(tableName = "mock_exam_results")
data class MockExamResult(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val examName: String,
    val subject: String,
    val score: Int,
    val totalQuestions: Int,
    val timeSpentSeconds: Int,
    val dateString: String,
    val rank: Int,
    val performanceFeedback: String
)

@Entity(tableName = "premium_requests")
data class PremiumRequest(
    @PrimaryKey val studentId: String,
    val bankName: String,
    val transactionId: String,
    val status: String, // "PENDING", "APPROVED", "REJECTED"
    val comment: String,
    val submitTime: String
)

@Entity(tableName = "offline_downloads")
data class OfflineDownload(
    @PrimaryKey val contentId: String, // e.g. "subject_biology", "note_physics_ch1"
    val title: String,
    val type: String, // "Subject", "Note", "Exam"
    val sizeMb: Double,
    val downloadedAt: String
)

// ==========================================
// 2. DAOs
// ==========================================

@Dao
interface UserProfileDao {
    @Query("SELECT * FROM user_profile LIMIT 1")
    fun getUserProfileFlow(): Flow<UserProfile?>

    @Query("SELECT * FROM user_profile LIMIT 1")
    suspend fun getUserProfile(): UserProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProfile(profile: UserProfile)

    @Query("UPDATE user_profile SET stream = :stream WHERE studentId = :studentId")
    suspend fun updateStream(studentId: String, stream: String)

    @Query("UPDATE user_profile SET name = :name, school = :school WHERE studentId = :studentId")
    suspend fun updatePersonalInfo(studentId: String, name: String, school: String)

    @Query("UPDATE user_profile SET isPremium = :status WHERE studentId = :studentId")
    suspend fun updatePremiumStatus(studentId: String, status: String)

    @Query("UPDATE user_profile SET points = :points WHERE studentId = :studentId")
    suspend fun updatePoints(studentId: String, points: Int)
}

@Dao
interface QuestionDao {
    @Query("SELECT * FROM questions")
    fun getAllQuestionsFlow(): Flow<List<Question>>

    @Query("SELECT * FROM questions WHERE stream = :stream OR stream = 'Both'")
    fun getQuestionsByStreamFlow(stream: String): Flow<List<Question>>

    @Query("SELECT * FROM questions WHERE subject = :subject")
    fun getQuestionsBySubjectFlow(subject: String): Flow<List<Question>>

    @Query("SELECT * FROM questions WHERE isBookmarked = 1")
    fun getBookmarkedQuestionsFlow(): Flow<List<Question>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestion(question: Question)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestions(questions: List<Question>)

    @Query("UPDATE questions SET isBookmarked = :isBookmarked WHERE id = :id")
    suspend fun updateBookmarkStatus(id: Int, isBookmarked: Boolean)

    @Query("UPDATE questions SET isDownloaded = :isDownloaded WHERE subject = :subject")
    suspend fun updateSubjectDownloadStatus(subject: String, isDownloaded: Boolean)

    @Query("DELETE FROM questions WHERE id = :id")
    suspend fun deleteQuestionById(id: Int)

    @Query("DELETE FROM questions")
    suspend fun deleteAllQuestions()
}

@Dao
interface MockExamResultDao {
    @Query("SELECT * FROM mock_exam_results ORDER BY id DESC")
    fun getAllResultsFlow(): Flow<List<MockExamResult>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResult(result: MockExamResult)
}

@Dao
interface PremiumRequestDao {
    @Query("SELECT * FROM premium_requests LIMIT 1")
    fun getRequestFlow(): Flow<PremiumRequest?>

    @Query("SELECT * FROM premium_requests")
    fun getAllRequestsFlow(): Flow<List<PremiumRequest>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRequest(request: PremiumRequest)

    @Query("UPDATE premium_requests SET status = :status, comment = :comment WHERE studentId = :studentId")
    suspend fun updateRequestStatus(studentId: String, status: String, comment: String)

    @Query("DELETE FROM premium_requests WHERE studentId = :studentId")
    suspend fun deleteRequest(studentId: String)
}

@Dao
interface OfflineDownloadDao {
    @Query("SELECT * FROM offline_downloads")
    fun getAllDownloadsFlow(): Flow<List<OfflineDownload>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownload(download: OfflineDownload)

    @Query("DELETE FROM offline_downloads WHERE contentId = :contentId")
    suspend fun deleteDownload(contentId: String)

    @Query("DELETE FROM offline_downloads")
    suspend fun clearAllDownloads()
}

// ==========================================
// 3. Database
// ==========================================

@Database(
    entities = [
        UserProfile::class,
        Question::class,
        MockExamResult::class,
        PremiumRequest::class,
        OfflineDownload::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ExamBridgeDatabase : RoomDatabase() {
    abstract fun userProfileDao(): UserProfileDao
    abstract fun questionDao(): QuestionDao
    abstract fun mockExamResultDao(): MockExamResultDao
    abstract fun premiumRequestDao(): PremiumRequestDao
    abstract fun offlineDownloadDao(): OfflineDownloadDao

    companion object {
        @Volatile
        private var INSTANCE: ExamBridgeDatabase? = null

        fun getDatabase(context: Context): ExamBridgeDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ExamBridgeDatabase::class.java,
                    "exam_bridge_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
