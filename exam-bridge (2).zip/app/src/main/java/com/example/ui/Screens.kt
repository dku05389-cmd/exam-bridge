package com.example.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppNotification
import com.example.data.MockExamResult
import com.example.data.PremiumRequest
import com.example.data.Question
import com.example.ui.theme.*

// ==========================================
// 1. SPLASH SCREEN
// ==========================================
@Composable
fun SplashScreen(isDark: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "Splash")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Scale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    if (isDark) listOf(DeepDarkSlate, DeepestVoid) else listOf(LightBg, LightSurface)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(110.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(RoyalBlue, SoftBrandBlue)))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.School,
                    contentDescription = "Logo",
                    tint = Color.White,
                    modifier = Modifier.size(60.dp)
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "EXAM BRIDGE",
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (isDark) Color.White else RoyalBlue,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Bridge Your Future Through Success",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = if (isDark) TextSecondaryDark else TextSecondaryLight,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ==========================================
// 2. ONBOARDING SCREENS
// ==========================================
@Composable
fun OnboardingScreen(
    viewModel: ExamBridgeViewModel,
    isDark: Boolean
) {
    var step by remember { mutableStateOf(1) }
    val title = when (step) {
        1 -> "Prepare Smarter"
        2 -> "Track Progress"
        else -> "Achieve Success"
    }
    val desc = when (step) {
        1 -> "Access thousands of entrance exam questions based on your stream."
        2 -> "Monitor your performance with detailed analytics and instant reviews."
        else -> "Practice, learn and succeed in university entrance exams."
    }
    val icon = when (step) {
        1 -> Icons.Default.MenuBook
        2 -> Icons.Default.BarChart
        else -> Icons.Default.WorkspacePremium
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    if (isDark) listOf(DeepDarkSlate, RichMidnight) else listOf(LightBg, LightSurface)
                )
            )
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .background(
                        Brush.radialGradient(listOf(RoyalBlue.copy(alpha = 0.4f), Color.Transparent)),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = RoyalBlue,
                    modifier = Modifier.size(70.dp)
                )
            }
            Spacer(modifier = Modifier.height(40.dp))
            Text(
                text = title,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = if (isDark) Color.White else TextPrimaryLight,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = desc,
                fontSize = 16.sp,
                color = if (isDark) TextSecondaryDark else TextSecondaryLight,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(modifier = Modifier.height(48.dp))

            // Step Indicator
            Row(horizontalArrangement = Arrangement.Center) {
                for (i in 1..3) {
                    Box(
                        modifier = Modifier
                            .size(if (i == step) 24.dp else 8.dp, 8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (i == step) RoyalBlue else Color.Gray.copy(alpha = 0.4f))
                            .padding(horizontal = 4.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                }
            }
        }

        // Action Buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { viewModel.navigateTo(Screen.Auth) }) {
                Text(text = "Skip", color = if (isDark) TextSecondaryDark else TextSecondaryLight)
            }

            Button(
                onClick = {
                    if (step < 3) step++ else viewModel.navigateTo(Screen.Auth)
                },
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(text = if (step == 3) "Get Started" else "Next", color = Color.White)
            }
        }
    }
}

// ==========================================
// 3. AUTHENTICATION (LOGIN / REGISTER)
// ==========================================
@Composable
fun AuthScreen(
    viewModel: ExamBridgeViewModel,
    isDark: Boolean
) {
    var isLoginMode by remember { mutableStateOf(true) }
    var email by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var school by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var rememberMe by remember { mutableStateOf(true) }

    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    if (isDark) listOf(DeepDarkSlate, DeepestVoid) else listOf(LightBg, LightSurface)
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.School,
                contentDescription = "Logo",
                tint = RoyalBlue,
                modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = if (isLoginMode) "Welcome Back" else "Create Account",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = if (isDark) Color.White else TextPrimaryLight
            )
            Text(
                text = if (isLoginMode) "Sign in to continue your success journey" else "Enter details to start your preparation",
                fontSize = 13.sp,
                color = if (isDark) TextSecondaryDark else TextSecondaryLight,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(24.dp))

            // Text Fields
            if (!isLoginMode) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name") },
                    leadingIcon = { Icon(Icons.Default.Person, "Name") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    leadingIcon = { Icon(Icons.Default.Phone, "Phone") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = school,
                    onValueChange = { school = it },
                    label = { Text("School Name") },
                    leadingIcon = { Icon(Icons.Default.Apartment, "School") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email Address") },
                leadingIcon = { Icon(Icons.Default.Email, "Email") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                leadingIcon = { Icon(Icons.Default.Lock, "Lock") },
                trailingIcon = {
                    IconButton(onClick = { showPassword = !showPassword }) {
                        Icon(
                            imageVector = if (showPassword) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = "Show Password"
                        )
                    }
                },
                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            )

            if (isLoginMode) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = rememberMe, onCheckedChange = { rememberMe = it })
                        Text("Remember Me", fontSize = 12.sp)
                    }
                    TextButton(onClick = { Toast.makeText(context, "Password reset code sent to your email", Toast.LENGTH_SHORT).show() }) {
                        Text("Forgot Password?", fontSize = 12.sp, color = RoyalBlue)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            PrimaryButton(
                text = if (isLoginMode) "Log In" else "Register Now",
                onClick = {
                    if (isLoginMode) {
                        viewModel.login(email, password, rememberMe,
                            onSuccess = { Toast.makeText(context, "Logged In successfully", Toast.LENGTH_SHORT).show() },
                            onError = { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() }
                        )
                    } else {
                        viewModel.register(name, email, phone, school) {
                            Toast.makeText(context, "Account Created!", Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Social Logins
            Text("Or connect with", fontSize = 12.sp, color = if (isDark) TextSecondaryDark else TextSecondaryLight)
            Spacer(modifier = Modifier.height(12.dp))
            SecondaryButton(
                text = "Continue with Google",
                icon = Icons.Default.AccountCircle,
                onClick = {
                    viewModel.register("Google Scholar", "google@student.edu", "+251900000000", "Addis Ababa Academy") {
                        Toast.makeText(context, "Signed in via Google", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))

            TextButton(onClick = { isLoginMode = !isLoginMode }) {
                Text(
                    text = if (isLoginMode) "Don't have an account? Register" else "Already have an account? Log In",
                    color = RoyalBlue,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ==========================================
// 4. STREAM SELECTION
// ==========================================
@Composable
fun StreamSelectScreen(
    viewModel: ExamBridgeViewModel,
    isDark: Boolean
) {
    var selectedStream by remember { mutableStateOf("") }
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    if (isDark) listOf(DeepDarkSlate, DeepestVoid) else listOf(LightBg, LightSurface)
                )
            )
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(modifier = Modifier.height(30.dp))
                Text(
                    text = "Choose Your Academic Stream",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) Color.White else TextPrimaryLight,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "This selection is permanent. You can change it later only from settings.",
                    fontSize = 13.sp,
                    color = if (isDark) TextSecondaryDark else TextSecondaryLight,
                    textAlign = TextAlign.Center
                )
            }

            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Natural Science
                val natSelected = selectedStream == "Natural Science"
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedStream = "Natural Science" }
                        .border(
                            if (natSelected) BorderStroke(3.dp, EmeraldGreen) else BorderStroke(0.dp, Color.Transparent),
                            shape = RoundedCornerShape(24.dp)
                        ),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isDark) GlassCardDark else GlassCardLight
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(RoyalBlue),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Science, "Natural", tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text("Natural Science", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("Biology, Physics, Chemistry, English, Maths, Aptitude", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }

                // Social Science
                val socSelected = selectedStream == "Social Science"
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedStream = "Social Science" }
                        .border(
                            if (socSelected) BorderStroke(3.dp, EmeraldGreen) else BorderStroke(0.dp, Color.Transparent),
                            shape = RoundedCornerShape(24.dp)
                        ),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isDark) GlassCardDark else GlassCardLight
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(GoldAccent),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Language, "Social", tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text("Social Science", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("History, Geography, Economics, English, Maths, Aptitude", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }
            }

            Button(
                onClick = {
                    if (selectedStream.isNotBlank()) {
                        viewModel.selectStream(selectedStream)
                    } else {
                        Toast.makeText(context, "Please choose a stream to continue", Toast.LENGTH_SHORT).show()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .navigationBarsPadding()
            ) {
                Text("Continue", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}
