package com.example.ui

import com.example.R
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

// ==========================================
// 1. DASHBOARD OVERVIEW & TABS
// ==========================================

@Composable
fun MainDashboardView(
    viewModel: ExamBridgeViewModel,
    profile: UserProfile,
    isDark: Boolean
) {
    val selectedTab by viewModel.dashboardTab.collectAsState()
    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val isTablet = configuration.screenWidthDp >= 720

    if (isTablet) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(if (isDark) DeepDarkSlate else LightBg)
        ) {
            // Sidebar Navigation on the Left
            DashboardSidebar(
                selectedTab = selectedTab,
                onTabSelected = { viewModel.setDashboardTab(it) },
                viewModel = viewModel,
                profile = profile,
                isDark = isDark
            )
            
            // Content area on the Right
            Scaffold(
                topBar = {
                    val title = when (selectedTab) {
                        0 -> "Dashboard Overview"
                        1 -> "Practice & Subject Prep"
                        2 -> "Mock Exams Center"
                        3 -> "My Study Notes"
                        4 -> "Student Profile"
                        else -> "Dashboard"
                    }
                    AppHeader(
                        title = title,
                        onMenuClick = { viewModel.isDrawerOpen.value = true },
                        onThemeToggle = { viewModel.toggleTheme() },
                        isDark = isDark,
                        onProfileClick = { viewModel.navigateTo(Screen.Profile) }
                    )
                },
                containerColor = if (isDark) DeepDarkSlate else LightBg
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (selectedTab) {
                        0 -> HomeTabResponsive(viewModel, profile, isDark)
                        1 -> ExamsTab(viewModel, profile, isDark)
                        2 -> UeeTab(viewModel, profile, isDark)
                        3 -> NotesTab(viewModel, profile, isDark)
                        4 -> ProfileTabContent(viewModel, profile, isDark)
                    }
                }
            }
        }
    } else {
        // Standard Mobile Scaffold with bottomBar
        Scaffold(
            topBar = {
                val title = when (selectedTab) {
                    0 -> "Exam Bridge"
                    1 -> "Exams"
                    2 -> "UEE"
                    3 -> "Notes"
                    4 -> "Profile"
                    else -> "Exam Bridge"
                }
                AppHeader(
                    title = title,
                    onMenuClick = { viewModel.isDrawerOpen.value = true },
                    onThemeToggle = { viewModel.toggleTheme() },
                    isDark = isDark,
                    onProfileClick = { viewModel.navigateTo(Screen.Profile) }
                )
            },
            bottomBar = {
                AppBottomBar(
                    selectedTab = selectedTab,
                    onTabSelected = { viewModel.setDashboardTab(it) },
                    isDark = isDark
                )
            },
            containerColor = if (isDark) DeepDarkSlate else LightBg
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (selectedTab) {
                    0 -> HomeTab(viewModel, profile, isDark)
                    1 -> ExamsTab(viewModel, profile, isDark)
                    2 -> UeeTab(viewModel, profile, isDark)
                    3 -> NotesTab(viewModel, profile, isDark)
                    4 -> ProfileTabContent(viewModel, profile, isDark)
                }
            }
        }
    }
}

@Composable
fun DashboardSidebar(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit,
    viewModel: ExamBridgeViewModel,
    profile: UserProfile,
    isDark: Boolean
) {
    val sidebarBg = if (isDark) Color(0xFF0F172A) else Color(0xFFEFF6FF)
    val sidebarBorder = if (isDark) Color.White.copy(alpha = 0.08f) else Color(0xFFD6E4FF)
    
    val items = listOf(
        Triple("Overview", Icons.Default.Dashboard, 0),
        Triple("Practice", Icons.Default.School, 1),
        Triple("Mock Exams", Icons.Default.Assignment, 2),
        Triple("Notes", Icons.Default.Notes, 3)
    )

    Row(
        modifier = Modifier
            .width(260.dp)
            .fillMaxHeight()
            .background(sidebarBg)
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(vertical = 24.dp, horizontal = 16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                // App Branding & Logo
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.School,
                        contentDescription = "Logo",
                        tint = if (isDark) GoldAccent else RoyalBlue,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Exam Bridge",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isDark) Color.White else Color(0xFF1E3A8A)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))
                Divider(color = sidebarBorder)
                Spacer(modifier = Modifier.height(16.dp))

                // Navigation Items
                items.forEach { (label, icon, tabIndex) ->
                    val selected = selectedTab == tabIndex
                    val itemBg = if (selected) {
                        if (isDark) Color(0xFF1E293B) else Color(0xFFD6E4FF)
                    } else {
                        Color.Transparent
                    }
                    val textColor = if (selected) {
                        if (isDark) GoldAccent else RoyalBlue
                    } else {
                        if (isDark) Color.LightGray else Color(0xFF4B5563)
                    }
                    val iconColor = if (selected) {
                        if (isDark) GoldAccent else RoyalBlue
                    } else {
                        if (isDark) Color.Gray else Color(0xFF9CA3AF)
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(itemBg)
                            .clickable { onTabSelected(tabIndex) }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = label,
                            tint = iconColor,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = label,
                            fontSize = 14.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            color = textColor
                        )
                    }
                }
                
                // Add Analytics direct link as a Sidebar item
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { viewModel.navigateTo(Screen.Analytics) }
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.BarChart,
                        contentDescription = "Analytics Report",
                        tint = if (isDark) Color.Gray else Color(0xFF9CA3AF),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = "Analytics",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (isDark) Color.LightGray else Color(0xFF4B5563)
                    )
                }
            }

            // Profile, Theme & Logout
            Column {
                Divider(color = sidebarBorder)
                Spacer(modifier = Modifier.height(16.dp))

                // Profile info
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isDark) Color(0xFF1E293B).copy(alpha = 0.5f) else Color.White)
                        .border(1.dp, sidebarBorder, RoundedCornerShape(12.dp))
                        .clickable { viewModel.navigateTo(Screen.Profile) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (isDark) GoldAccent else RoyalBlue),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = profile.name.take(2).uppercase(),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = profile.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (isDark) Color.White else Color(0xFF1F2937),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = profile.email,
                            fontSize = 10.sp,
                            color = Color.Gray,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Theme Toggle Action
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { viewModel.toggleTheme() }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Theme",
                            tint = if (isDark) Color.LightGray else Color(0xFF4B5563),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (isDark) "Light Mode" else "Dark Mode",
                            fontSize = 12.sp,
                            color = if (isDark) Color.LightGray else Color(0xFF4B5563)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Logout Action
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { viewModel.logout() }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.ExitToApp,
                        contentDescription = "Logout",
                        tint = Color.Red,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Sign Out",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Red
                    )
                }
            }
        }
        Divider(
            modifier = Modifier
                .width(1.dp)
                .fillMaxHeight(),
            color = sidebarBorder
        )
    }
}

@Composable
fun HomeTabResponsive(
    viewModel: ExamBridgeViewModel,
    profile: UserProfile,
    isDark: Boolean
) {
    val selectedStream by viewModel.selectedStreamFilter.collectAsState()
    val subjects = when (selectedStream) {
        "Social Science" -> listOf("History", "Geography", "Economics", "English", "Mathematics", "Aptitude")
        else -> listOf("Biology", "Physics", "Chemistry", "English", "Mathematics", "Aptitude")
    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(if (isDark) DeepDarkSlate else LightBg)
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Column (60% width): Welcome and Subjects List
        Column(
            modifier = Modifier
                .weight(1.5f)
                .fillMaxHeight()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Welcome Card
            WelcomeBannerCard(profile, viewModel, isDark)

            // Quick Actions
            QuickActionsSection(viewModel, isDark)

            // Motivational Banner
            MotivationalBanner(isDark)

            // My Subjects Section Title
            Text(
                text = "My Subjects & Practice Progress",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = if (isDark) Color.White else Color(0xFF111827),
                modifier = Modifier.padding(top = 8.dp)
            )

            // Subject Cards (Grid Layout of subjects for wider screens!)
            val chunkedSubjects = subjects.chunked(2)
            chunkedSubjects.forEach { pair ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    pair.forEach { subject ->
                        Box(modifier = Modifier.weight(1f)) {
                            PremiumSubjectCard(
                                subject = subject,
                                isDownloaded = false,
                                isPremium = profile.isPremium == "PREMIUM",
                                isDark = isDark,
                                onDownload = {
                                    Toast.makeText(viewModel.getApplication(), "$subject saved offline!", Toast.LENGTH_SHORT).show()
                                },
                                onStart = {
                                    viewModel.startPractice(subject, "All Core Content")
                                }
                            )
                        }
                    }
                    if (pair.size < 2) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        // Right Column (40% width): User Statistics Overview Dashboard
        Card(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isDark) GlassCardDark else Color.White
            ),
            border = BorderStroke(1.dp, if (isDark) GlassBorderDark else Color(0xFFD6E4FF)),
            elevation = CardDefaults.cardElevation(defaultElevation = if (isDark) 0.dp else 4.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "User Statistics",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) Color.White else Color(0xFF111827)
                )

                // Streak, Goal & Rank Info (A grid inside a vertical list)
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Box(modifier = Modifier.weight(1f)) {
                            MiniStatCard(
                                title = "Study Streak",
                                value = "35 Days",
                                subtitle = "Keep it up! 🔥",
                                icon = Icons.Default.LocalFireDepartment,
                                iconColor = Color(0xFF3B82F6),
                                isDark = isDark
                            )
                        }
                        Box(modifier = Modifier.weight(1f)) {
                            MiniStatCard(
                                title = "Daily Goal",
                                value = "1.5 / 2 Hrs",
                                subtitle = "75% Done ⏰",
                                icon = Icons.Default.Schedule,
                                iconColor = Color(0xFF10B981),
                                isDark = isDark
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Box(modifier = Modifier.weight(1f)) {
                            MiniStatCard(
                                title = "Weekly Rank",
                                value = "Top 12%",
                                subtitle = "Amazing! 🏆",
                                icon = Icons.Default.EmojiEvents,
                                iconColor = Color(0xFFF59E0B),
                                isDark = isDark
                            )
                        }
                        Box(modifier = Modifier.weight(1f)) {
                            MiniStatCard(
                                title = "Overall Accuracy",
                                value = "84.5%",
                                subtitle = "Above Avg 📈",
                                icon = Icons.Default.CheckCircle,
                                iconColor = Color(0xFF8B5CF6),
                                isDark = isDark
                            )
                        }
                    }
                }

                Divider(color = if (isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFEFF6FF))

                // Accuracy Trend Line Chart
                Text(
                    text = "Accuracy Performance",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) Color.White else Color(0xFF1F2937)
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                ) {
                    PerformanceLineChart(isDark)
                }

                Divider(color = if (isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFEFF6FF))

                // Activity Bar Chart
                Text(
                    text = "Weekly Activity Hour",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) Color.White else Color(0xFF1F2937)
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                ) {
                    MonthlyBarChart(isDark)
                }
            }
        }
    }
}

// ==========================================
// 2. TAB: HOME
// ==========================================
@Composable
fun HomeTab(
    viewModel: ExamBridgeViewModel,
    profile: UserProfile,
    isDark: Boolean
) {
    val selectedStream by viewModel.selectedStreamFilter.collectAsState()
    val subjects = when (selectedStream) {
        "Social Science" -> listOf("History", "Geography", "Economics", "English", "Mathematics", "Aptitude")
        else -> listOf("Biology", "Physics", "Chemistry", "English", "Mathematics", "Aptitude")
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(if (isDark) DeepDarkSlate else LightBg),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // 1. Welcome Banner
        item {
            WelcomeBannerCard(profile, viewModel, isDark)
        }

        // 2. Quick Actions Header and Grid
        item {
            QuickActionsSection(viewModel, isDark)
        }

        // 3. Motivational Banner
        item {
            MotivationalBanner(isDark)
        }

        // 4. My Subjects Progress
        item {
            Text(
                text = "My Subjects & Practice Progress",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = if (isDark) Color.White else Color(0xFF111827),
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 8.dp)
            )
        }
        items(subjects) { subject ->
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                PremiumSubjectCard(
                    subject = subject,
                    isDownloaded = false,
                    isPremium = profile.isPremium == "PREMIUM",
                    isDark = isDark,
                    onDownload = {
                        Toast.makeText(viewModel.getApplication(), "$subject saved offline!", Toast.LENGTH_SHORT).show()
                    },
                    onStart = {
                        viewModel.startPractice(subject, "All Core Content")
                    }
                )
            }
        }
    }
}

@Composable
fun WelcomeBannerCard(
    profile: UserProfile,
    viewModel: ExamBridgeViewModel,
    isDark: Boolean
) {
    val containerBg = if (isDark) {
        Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF0F172A)))
    } else {
        Brush.linearGradient(listOf(Color(0xFFEFF6FF), Color(0xFFDBEAFE)))
    }

    val borderColor = if (isDark) Color.White.copy(alpha = 0.08f) else Color(0xFFDBEAFE)
    val nameColor = if (isDark) Color.White else Color(0xFF0F172A)
    val subtitleColor = if (isDark) Color.LightGray else Color(0xFF475569)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        border = BorderStroke(width = 1.dp, color = borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isDark) 0.dp else 2.dp)
    ) {
        Box(
            modifier = Modifier
                .background(containerBg)
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left Column: Welcome text & details
                Column(
                    modifier = Modifier.weight(0.58f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "👋 Welcome Back,",
                        color = if (isDark) Color(0xFF93C5FD) else Color(0xFF2563EB),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Text(
                        text = "${profile.name}!",
                        color = nameColor,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    
                    Text(
                        text = "Keep going! Your future self is proud of your progress.",
                        color = subtitleColor,
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                        fontWeight = FontWeight.Normal
                    )

                    // Capsule Button: Keep Learning 🚀
                    Button(
                        onClick = { viewModel.setDashboardTab(1) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(50),
                        modifier = Modifier
                            .padding(top = 4.dp)
                            .height(38.dp)
                    ) {
                        Text(
                            text = "Keep Learning 🚀",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Daily Stats Row inside Banner (Streak and Goal)
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isDark) Color(0xFF1E293B) else Color.White
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (isDark) Color.White.copy(alpha = 0.08f) else Color(0xFFE2E8F0)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Streak
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text("🔥", fontSize = 16.sp)
                                Column {
                                    Text(
                                        text = "${profile.streakDays}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDark) Color.White else Color(0xFF0F172A)
                                    )
                                    Text(
                                        text = "Day Streak",
                                        fontSize = 9.sp,
                                        color = Color.Gray
                                    )
                                }
                            }

                            // Divider
                            VerticalDivider(
                                modifier = Modifier.height(24.dp),
                                thickness = 1.dp,
                                color = if (isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFE2E8F0)
                            )

                            // Goal
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text("🎯", fontSize = 16.sp)
                                Column {
                                    Text(
                                        text = "2/3",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDark) Color.White else Color(0xFF0F172A)
                                    )
                                    Text(
                                        text = "Daily Goal",
                                        fontSize = 9.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }
                    }
                }

                // Right Column: Image
                Box(
                    modifier = Modifier
                        .weight(0.42f)
                        .height(140.dp)
                        .padding(start = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_hero_banner),
                        contentDescription = "Learning Illustration",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}

@Composable
fun DailyStatsRow(isDark: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Card 1: Study Streak
        MiniStatCard(
            modifier = Modifier.weight(1f),
            title = "Study Streak",
            value = "35 Days",
            subtitle = "Keep it up! 🔥",
            icon = Icons.Default.LocalFireDepartment,
            iconColor = Color(0xFF3B82F6),
            isDark = isDark
        )

        // Card 2: Daily Goal
        MiniStatCard(
            modifier = Modifier.weight(1f),
            title = "Daily Goal",
            value = "2 Hours",
            subtitle = "of 2 Hours",
            icon = Icons.Default.Schedule,
            iconColor = Color(0xFF10B981),
            isDark = isDark
        )

        // Card 3: Weekly Rank
        MiniStatCard(
            modifier = Modifier.weight(1f),
            title = "Weekly Rank",
            value = "Top 12%",
            subtitle = "Amazing! 🏆",
            icon = Icons.Default.EmojiEvents,
            iconColor = Color(0xFFF59E0B),
            isDark = isDark
        )
    }
}

@Composable
fun MiniStatCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    isDark: Boolean
) {
    val containerColor = if (isDark) GlassCardDark else Color.White
    val borderColor = if (isDark) GlassBorderDark else Color(0xFFD6E4FF)

    Card(
        modifier = modifier.height(130.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isDark) 0.dp else 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Icon circular wrapper
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(iconColor.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconColor,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                color = if (isDark) Color.LightGray else Color(0xFF6B7280),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                color = if (isDark) Color.White else Color(0xFF111827),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                color = if (isDark) Color.LightGray.copy(alpha = 0.7f) else Color(0xFF6B7280),
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun QuickActionCardLarge(
    title: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    bgLightColor: Color,
    isDark: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val containerBg = if (isDark) GlassCardDark else bgLightColor
    val borderColor = if (isDark) color.copy(alpha = 0.2f) else color.copy(alpha = 0.08f)

    Card(
        modifier = modifier
            .height(165.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = containerBg),
        border = BorderStroke(1.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isDark) 0.dp else 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top: Icon
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Middle: Title & Description
            Column(
                modifier = Modifier.weight(1f).padding(top = 8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = color
                )
                Text(
                    text = desc,
                    fontSize = 11.sp,
                    color = if (isDark) Color.LightGray else Color(0xFF475569),
                    lineHeight = 14.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Bottom Right: Navigation Chevron
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Go",
                        tint = color,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun MotivationalBanner(isDark: Boolean) {
    val bgGradient = if (isDark) {
        Brush.linearGradient(listOf(Color(0xFF0F172A), Color(0xFF1E3A8A).copy(alpha = 0.4f)))
    } else {
        Brush.linearGradient(listOf(Color(0xFFEFF6FF), Color(0xFFDBEAFE)))
    }

    val borderColor = if (isDark) Color.White.copy(alpha = 0.08f) else Color(0xFFD6E4FF)
    val quoteCircleBg = if (isDark) Color.White.copy(alpha = 0.1f) else Color.White

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        border = BorderStroke(1.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isDark) 0.dp else 2.dp)
    ) {
        Box(
            modifier = Modifier
                .background(bgGradient)
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left text side
                Row(
                    modifier = Modifier.weight(1.2f),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    // Quotation mark circular icon
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(quoteCircleBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "“",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF2563EB)
                        )
                    }

                    Column(
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "Small steps every day lead to big results.",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color.White else Color(0xFF0F172A),
                            lineHeight = 18.sp
                        )
                        Text(
                            text = "You've got this! 💪",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color(0xFF93C5FD) else Color(0xFF2563EB)
                        )
                    }
                }

                // Right Illustration side (Compose custom drawn stack of books and a gold trophy)
                Box(
                    modifier = Modifier
                        .weight(0.8f)
                        .height(90.dp)
                        .padding(start = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        // Flying paper planes
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = null,
                            tint = if (isDark) Color(0xFF60A5FA).copy(alpha = 0.5f) else Color(0xFF3B82F6).copy(alpha = 0.3f),
                            modifier = Modifier
                                .size(14.dp)
                                .align(Alignment.TopStart)
                        )
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = null,
                            tint = if (isDark) Color(0xFF60A5FA).copy(alpha = 0.4f) else Color(0xFF3B82F6).copy(alpha = 0.2f),
                            modifier = Modifier
                                .size(12.dp)
                                .align(Alignment.BottomStart)
                        )

                        // Books at the bottom
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy((-3).dp)
                        ) {
                            // Stack of books represented by flat capsules
                            Box(
                                modifier = Modifier
                                    .width(64.dp)
                                    .height(10.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Color(0xFF3B82F6))
                            )
                            Box(
                                modifier = Modifier
                                    .width(68.dp)
                                    .height(11.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Color(0xFF2563EB))
                            )
                        }

                        // Gold Trophy in the center, resting on the books
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .padding(bottom = 12.dp)
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFFFBEB)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = "Trophy",
                                tint = Color(0xFFF59E0B),
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuickActionsSection(
    viewModel: ExamBridgeViewModel,
    isDark: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        // Section Header
        Text(
            text = "Quick Actions",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = if (isDark) Color.White else Color(0xFF111827),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Grid (2x2)
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionCardLarge(
                    modifier = Modifier.weight(1f),
                    title = "Practice",
                    desc = "Improve your skills with practice questions.",
                    icon = Icons.Default.Book,
                    color = Color(0xFF2563EB),
                    bgLightColor = Color(0xFFEFF6FF),
                    isDark = isDark,
                    onClick = { viewModel.setDashboardTab(1) }
                )
                QuickActionCardLarge(
                    modifier = Modifier.weight(1f),
                    title = "Mock Exam",
                    desc = "Test yourself with full length mock exams.",
                    icon = Icons.Default.Assignment,
                    color = Color(0xFF10B981),
                    bgLightColor = Color(0xFFF0FDF4),
                    isDark = isDark,
                    onClick = { viewModel.navigateTo(Screen.MockCenter) }
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionCardLarge(
                    modifier = Modifier.weight(1f),
                    title = "Notes",
                    desc = "Read and review important study notes.",
                    icon = Icons.Default.Description,
                    color = Color(0xFF8B5CF6),
                    bgLightColor = Color(0xFFF5F3FF),
                    isDark = isDark,
                    onClick = { viewModel.setDashboardTab(3) }
                )
                QuickActionCardLarge(
                    modifier = Modifier.weight(1f),
                    title = "Premium",
                    desc = "Unlock premium features and study smart.",
                    icon = Icons.Default.WorkspacePremium,
                    color = Color(0xFFF59E0B),
                    bgLightColor = Color(0xFFFFFBEB),
                    isDark = isDark,
                    onClick = { viewModel.navigateTo(Screen.PremiumUpgrade) }
                )
            }
        }
    }
}

@Composable
fun QuickActionCard(
    modifier: Modifier = Modifier,
    title: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    isDark: Boolean,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(if (isPressed) 0.95f else 1f, label = "quick_action_press_scale")
    val elevation by animateDpAsState(if (isPressed) 1.dp else (if (isDark) 0.dp else 4.dp), label = "quick_action_press_elevation")

    val containerColor = if (isDark) GlassCardDark else Color.White
    val borderColor = if (isDark) GlassBorderDark else Color(0xFFD6E4FF)

    Card(
        modifier = modifier
            .height(115.dp)
            .scale(scale)
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(),
                onClick = onClick
            ),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = elevation)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Icon wrapper circle
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isDark) Color.White else Color(0xFF1F2937),
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = desc,
                fontSize = 8.5.sp,
                color = if (isDark) Color.LightGray.copy(alpha = 0.8f) else Color(0xFF6B7280),
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun ContinueLearningSection(
    subjectName: String,
    viewModel: ExamBridgeViewModel,
    isDark: Boolean
) {
    val context = LocalContext.current
    val actualSubject = if (subjectName.isNotEmpty()) subjectName else "Geography"

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Continue Learning",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = if (isDark) Color.White else Color(0xFF111827)
            )
            Text(
                text = "View All ›",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = RoyalBlue,
                modifier = Modifier.clickable {
                    viewModel.setDashboardTab(1)
                }
            )
        }
        Spacer(modifier = Modifier.height(12.dp))

        // Main Card
        val containerColor = if (isDark) GlassCardDark else Color.White
        val borderColor = if (isDark) GlassBorderDark else Color(0xFFE5E7EB)

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = containerColor),
            border = BorderStroke(1.dp, borderColor),
            elevation = CardDefaults.cardElevation(defaultElevation = if (isDark) 0.dp else 3.dp)
        ) {
            Column(
                modifier = Modifier.padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Circular subject icon background
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFEFF6FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Public,
                            contentDescription = null,
                            tint = RoyalBlue,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    // Text column
                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = actualSubject,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) Color.White else Color(0xFF111827)
                        )
                        Text(
                            text = "Chapter 3: Human Population",
                            fontSize = 13.sp,
                            color = if (isDark) Color.LightGray else Color(0xFF4B5563)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Continue Button
                    Box(
                        modifier = Modifier
                            .background(RoyalBlue, RoundedCornerShape(16.dp))
                            .clickable {
                                Toast.makeText(context, "Resuming learning: $actualSubject", Toast.LENGTH_SHORT).show()
                                viewModel.navigateTo(Screen.Practice)
                            }
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = "Continue",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Progress Bar and Percent text row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LinearProgressIndicator(
                        progress = { 0.68f },
                        modifier = Modifier
                            .weight(1f)
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = RoyalBlue,
                        trackColor = if (isDark) Color.White.copy(alpha = 0.15f) else Color(0xFFEFF6FF)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "68%",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) Color.White else Color(0xFF1F2937)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Stats row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LearningStatLabel(
                        icon = Icons.Default.TaskAlt,
                        label = "24 Questions",
                        isDark = isDark
                    )
                    LearningStatLabel(
                        icon = Icons.Default.CheckCircle,
                        label = "78% Accuracy",
                        isDark = isDark
                    )
                    LearningStatLabel(
                        icon = Icons.Default.Schedule,
                        label = "15 min left",
                        isDark = isDark
                    )
                }
            }
        }
    }
}

@Composable
fun LearningStatLabel(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isDark: Boolean
) {
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = RoyalBlue,
            modifier = Modifier.size(15.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            color = if (isDark) Color.LightGray else Color(0xFF4B5563)
        )
    }
}

// ==========================================
// 3. TAB: EXAMS (Practice Mode Prep)
// ==========================================
@Composable
fun ExamsTab(
    viewModel: ExamBridgeViewModel,
    profile: UserProfile,
    isDark: Boolean
) {
    var searchQuery by remember { mutableStateOf("") }
    val selectedStream by viewModel.selectedStreamFilter.collectAsState()
    val subjects = when (selectedStream) {
        "Social Science" -> listOf("History", "Geography", "Economics", "English", "Mathematics", "Aptitude")
        else -> listOf("Biology", "Physics", "Chemistry", "English", "Mathematics", "Aptitude")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else Color.White),
            border = BorderStroke(if (isDark) 1.dp else 1.5.dp, if (isDark) GlassBorderDark else Color(0xFFD6E4FF)),
            elevation = CardDefaults.cardElevation(defaultElevation = if (isDark) 0.dp else 4.dp)
        ) {
            androidx.compose.foundation.text.BasicTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                textStyle = androidx.compose.ui.text.TextStyle(
                    color = if (isDark) Color.White else Color(0xFF111827),
                    fontSize = 16.sp
                ),
                decorationBox = { innerTextField ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Search, "Search", tint = RoyalBlue, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Box(modifier = Modifier.weight(1f)) {
                            if (searchQuery.isEmpty()) {
                                Text("Search Subjects / Topics", color = Color.Gray, fontSize = 16.sp)
                            }
                            innerTextField()
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(Icons.Default.Tune, "Filter", tint = RoyalBlue, modifier = Modifier.size(24.dp))
                    }
                },
                cursorBrush = androidx.compose.ui.graphics.SolidColor(RoyalBlue)
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text("Select Topic to Practice", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            val filtered = subjects.filter { it.contains(searchQuery, ignoreCase = true) }
            items(filtered) { subject ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else Color.White),
                    border = BorderStroke(if (isDark) 1.dp else 1.5.dp, if (isDark) GlassBorderDark else Color(0xFFD6E4FF)),
                    elevation = CardDefaults.cardElevation(defaultElevation = if (isDark) 0.dp else 4.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(subject, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = RoyalBlue)
                            Icon(Icons.Default.PlayArrow, "Start", tint = RoyalBlue)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Topics available for practice:", fontSize = 12.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(6.dp))

                        val topics = when (subject) {
                            "Biology" -> listOf("Cell Biology", "Genetics", "Ecology", "Plant Systems")
                            "Physics" -> listOf("Mechanics", "Thermodynamics", "Electromagnetism")
                            "Chemistry" -> listOf("Atomic Structure", "Chemical Bonding", "Organic Chemistry")
                            "History" -> listOf("Ethiopian History", "World War I", "Ancient Civilizations")
                            "Geography" -> listOf("Physical Geography", "Human Geography", "GIS Mapping")
                            "Economics" -> listOf("Microeconomics", "Macroeconomics", "Trade Policies")
                            else -> listOf("All Core Content", "Random Assorted Questions")
                        }

                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            topics.forEach { topic ->
                                Box(
                                    modifier = Modifier
                                        .background(SoftBrandBlue.copy(alpha = 0.2f), shape = RoundedCornerShape(12.dp))
                                        .clickable { viewModel.startPractice(subject, topic) }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(topic, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isDark) Color.White else Color.Black)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 4. TAB: UEE (Mock Exams Center)
// ==========================================
@Composable
fun UeeTab(
    viewModel: ExamBridgeViewModel,
    profile: UserProfile,
    isDark: Boolean
) {
    val results by viewModel.allMockResults.collectAsState(initial = emptyList())
    val selectedStream by viewModel.selectedStreamFilter.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SoftBrandBlue),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("National UEE Mock Center", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Simulate the actual Ethiopian Higher Education Entrance Certificate Examination environment.", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                }
            }
        }



        item {
            Text("Available Exam Categories ($selectedStream)", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }

        val exams = listOf(
            Triple("Full Entrance Exam Simulation", "120 Mins • 100 Questions", Icons.Default.Timeline),
            Triple("Subject Diagnostic Exam", "60 Mins • 50 Questions", Icons.Default.Assignment),
            Triple("Timed Speed Challenge", "30 Mins • 30 Questions", Icons.Default.HourglassTop),
            Triple("Random Assorted Question Bank", "Unlimited Time • Custom Counts", Icons.Default.Psychology)
        )

        items(exams) { (title, subtitle, icon) ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(GoldAccent.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(icon, title, tint = GoldAccent)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(subtitle, fontSize = 12.sp, color = Color.Gray)
                        }
                    }

                    Button(
                        onClick = { viewModel.startMockExam(title) },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Start", fontSize = 12.sp, color = Color.White)
                    }
                }
            }
        }

        if (results.isNotEmpty()) {
            item {
                Text("Your Submission History", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            items(results) { res ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(res.examName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(res.dateString, fontSize = 11.sp, color = Color.Gray)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Score: ${res.score}/${res.totalQuestions}", fontWeight = FontWeight.Bold, color = EmeraldGreen, fontSize = 14.sp)
                            Text("Rank: #${res.rank}", fontSize = 11.sp, color = GoldAccent, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. TAB: NOTES (Core Materials)
// ==========================================
@Composable
fun NotesTab(
    viewModel: ExamBridgeViewModel,
    profile: UserProfile,
    isDark: Boolean
) {
    val context = LocalContext.current
    var selectedCategory by remember { mutableStateOf("Short Notes") }
    val categories = listOf("Short Notes", "PDF Notes", "Formula Sheets", "Revision Guides")

    val isPremium = profile.isPremium == "PREMIUM"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            categories.forEach { cat ->
                val selected = selectedCategory == cat
                Box(
                    modifier = Modifier
                        .background(
                            if (selected) RoyalBlue else SoftBrandBlue.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable { selectedCategory = cat }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        cat,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (selected) Color.White else (if (isDark) Color.White else Color.Black)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        val notes = listOf(
            Pair("Biology Chapter 1: Introduction to Cytology", "PDF • 2.5 MB"),
            Pair("Physics Chapter 1: Units, Vectors & Kinematics", "PDF • 3.1 MB"),
            Pair("Chemistry Chapter 1: Modern Atomic Configurations", "PDF • 1.9 MB"),
            Pair("Aptitude Core shortcuts & logic maps", "PDF • 4.5 MB"),
            Pair("English Grammar Tenses revision guide", "PDF • 1.2 MB")
        )

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(notes) { (title, subtitle) ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else Color.White),
                    border = BorderStroke(if (isDark) 1.dp else 1.5.dp, if (isDark) GlassBorderDark else Color(0xFFD6E4FF)),
                    elevation = CardDefaults.cardElevation(defaultElevation = if (isDark) 0.dp else 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(subtitle, fontSize = 12.sp, color = Color.Gray)
                        }

                        IconButton(onClick = {
                            if (isPremium) {
                                Toast.makeText(context, "Material downloaded successfully!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Free Tier Limit: First chapter only! Upgrade to Premium to unlock.", Toast.LENGTH_LONG).show()
                                viewModel.navigateTo(Screen.PremiumUpgrade)
                            }
                        }) {
                            Icon(
                                imageVector = if (isPremium) Icons.Default.CloudDownload else Icons.Default.Lock,
                                contentDescription = "Download",
                                tint = if (isPremium) EmeraldGreen else GoldAccent
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PremiumActionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    isDark: Boolean,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(if (isPressed) 0.97f else 1f)
    val elevation by animateDpAsState(if (isPressed) 2.dp else (if (isDark) 0.dp else 4.dp))

    val borderColor = if (isDark) GlassBorderDark else Color(0xFFD6E4FF)
    val containerColor = if (isDark) GlassCardDark else Color.White
    
    Card(
        modifier = Modifier
            .width(150.dp)
            .scale(scale)
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(),
                onClick = onClick
            ),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(if (isDark) 1.dp else 1.5.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = elevation)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(iconColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = iconColor, modifier = Modifier.size(24.dp))
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = if (isDark) Color.White else Color(0xFF111827))
            Spacer(modifier = Modifier.height(4.dp))
            Text(subtitle, fontSize = 12.sp, color = if (isDark) Color.LightGray else Color(0xFF6B7280))
        }
    }
}

@Composable
fun PremiumSubjectCard(
    subject: String,
    isDownloaded: Boolean,
    isPremium: Boolean,
    isDark: Boolean,
    onDownload: () -> Unit,
    onStart: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(if (isPressed) 0.98f else 1f)
    val elevation by animateDpAsState(if (isPressed) 2.dp else (if (isDark) 0.dp else 6.dp))

    val borderColor = if (isDark) GlassBorderDark else Color(0xFFD6E4FF)
    val containerColor = if (isDark) GlassCardDark else Color.White

    val icon = when (subject) {
        "Biology" -> Icons.Default.Science
        "Physics" -> Icons.Default.Bolt
        "Chemistry" -> Icons.Default.AutoAwesome
        "History" -> Icons.Default.MenuBook
        "Geography" -> Icons.Default.Public
        "Economics" -> Icons.Default.Paid
        "English" -> Icons.Default.Translate
        "Mathematics" -> Icons.Default.Functions
        else -> Icons.Default.Psychology
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale)
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(),
                onClick = onStart
            ),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(if (isDark) 1.dp else 1.5.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = elevation)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(RoyalBlue.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, contentDescription = subject, tint = RoyalBlue, modifier = Modifier.size(28.dp))
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(subject, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = if (isDark) Color.White else Color(0xFF111827))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("150+ Questions • 84% Accuracy", fontSize = 13.sp, color = if (isDark) Color.LightGray else Color(0xFF6B7280))
                    }
                }
                
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(48.dp)
                ) {
                    androidx.compose.material3.CircularProgressIndicator(
                        progress = 0.78f,
                        color = EmeraldGreen,
                        trackColor = EmeraldGreen.copy(alpha = 0.2f),
                        strokeWidth = 4.dp,
                        modifier = Modifier.size(40.dp)
                    )
                    Text("78%", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (isDark) Color.White else Color(0xFF111827))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Download button (Premium)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                                colors = listOf(Color(0xFF2563EB), Color(0xFF3B82F6))
                            )
                        )
                        .clickable { onDownload() }
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isDownloaded) Icons.Default.FileDownloadDone else Icons.Default.FileDownload,
                            contentDescription = "Download",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isDownloaded) "Downloaded" else "Save Offline", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Start Learning Button
                Text(
                    text = "Start Learning",
                    color = RoyalBlue,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier
                        .clickable { onStart() }
                        .padding(8.dp)
                )
            }
        }
    }
}
