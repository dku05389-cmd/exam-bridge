package com.example.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

// ==========================================
// 1. PRACTICE MODE WORKFLOW
// ==========================================
@Composable
fun PracticeScreen(
    viewModel: ExamBridgeViewModel,
    isDark: Boolean
) {
    val questions by viewModel.practiceQuestions.collectAsState()
    val currentIndex by viewModel.currentQuestionIndex.collectAsState()
    val timerSeconds by viewModel.practiceTimerSeconds.collectAsState()
    val answers by viewModel.userAnswers.collectAsState()
    val bookmarkedIds by viewModel.bookmarkedIds.collectAsState()
    val showResults by viewModel.showPracticeResults.collectAsState()
    val isTimerActive by viewModel.isPracticeTimerActive.collectAsState()

    val context = LocalContext.current

    if (questions.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = RoyalBlue)
        }
        return
    }

    val currentQuestion = questions[currentIndex]
    val selectedOption = answers[currentIndex]
    val isBookmarked = bookmarkedIds.contains(currentQuestion.id)

    val options = listOf(
        "A" to currentQuestion.optionA,
        "B" to currentQuestion.optionB,
        "C" to currentQuestion.optionC,
        "D" to currentQuestion.optionD
    )

    Scaffold(
        topBar = {
            AppHeader(
                title = "Practice: ${viewModel.activeSubject.value}",
                onMenuClick = {},
                onThemeToggle = { viewModel.toggleTheme() },
                isDark = isDark,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = if (isDark) DeepDarkSlate else LightBg
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {
            if (!showResults) {
                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val isTablet = maxWidth >= 720.dp
                    if (isTablet) {
                        // Dual column layout for larger screens / tablets / landscape mode
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Left Column (Question Details + Explanation)
                            Column(
                                modifier = Modifier
                                    .weight(1.2f)
                                    .fillMaxHeight()
                                    .verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                // Topic badge & Bookmark row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .background(RoyalBlue.copy(alpha = 0.15f), shape = RoundedCornerShape(8.dp))
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(currentQuestion.topic, fontSize = 12.sp, color = RoyalBlue, fontWeight = FontWeight.Bold)
                                    }

                                    IconButton(onClick = { viewModel.toggleBookmark(currentQuestion.id, isBookmarked) }) {
                                        Icon(
                                            imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                            contentDescription = "Bookmark",
                                            tint = GoldAccent
                                        )
                                    }
                                }

                                // Question Text Card
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(20.dp),
                                    colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else Color.White)
                                ) {
                                    Column(modifier = Modifier.padding(24.dp)) {
                                        Text(
                                            text = currentQuestion.questionText,
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold,
                                            lineHeight = 26.sp,
                                            color = if (isDark) Color.White else Color.Black
                                        )
                                    }
                                }

                                // Explanation (Immediate Feedback)
                                if (selectedOption != null) {
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(20.dp),
                                        colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else Color.White),
                                        border = BorderStroke(1.dp, RoyalBlue.copy(alpha = 0.2f))
                                    ) {
                                        Column(modifier = Modifier.padding(20.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Lightbulb, "Explanation", tint = GoldAccent, modifier = Modifier.size(22.dp))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text("Explanation", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = RoyalBlue)
                                            }
                                            Spacer(modifier = Modifier.height(10.dp))
                                            Text(
                                                text = currentQuestion.explanation,
                                                fontSize = 14.sp,
                                                lineHeight = 22.sp,
                                                color = if (isDark) Color.LightGray else Color.DarkGray
                                            )
                                        }
                                    }
                                }
                            }

                            // Right Column (Timer, Navigation, Options, Controls)
                            Column(
                                modifier = Modifier
                                    .weight(0.8f)
                                    .fillMaxHeight()
                                    .verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                TimerCard(timerSeconds, isTimerActive, isDark, viewModel)

                                QuestionNavigationRow(currentIndex, questions, answers, bookmarkedIds, isDark, viewModel)

                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    OptionsList(options, selectedOption, currentQuestion, isDark, currentIndex, viewModel)
                                }

                                Spacer(modifier = Modifier.weight(1f, fill = false))

                                NavigationControlRow(currentIndex, questions, selectedOption, context, viewModel)
                            }
                        }
                    } else {
                        // Mobile Layout: Single column scrollable
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                                .padding(16.dp)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            TimerCard(timerSeconds, isTimerActive, isDark, viewModel)

                            QuestionNavigationRow(currentIndex, questions, answers, bookmarkedIds, isDark, viewModel)

                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(20.dp),
                                colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else Color.White)
                            ) {
                                Column(modifier = Modifier.padding(20.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .background(RoyalBlue.copy(alpha = 0.15f), shape = RoundedCornerShape(8.dp))
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(currentQuestion.topic, fontSize = 11.sp, color = RoyalBlue, fontWeight = FontWeight.Bold)
                                        }

                                        IconButton(onClick = { viewModel.toggleBookmark(currentQuestion.id, isBookmarked) }) {
                                            Icon(
                                                imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                                contentDescription = "Bookmark",
                                                tint = GoldAccent
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = currentQuestion.questionText,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        lineHeight = 24.sp,
                                        color = if (isDark) Color.White else Color.Black
                                    )
                                }
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                OptionsList(options, selectedOption, currentQuestion, isDark, currentIndex, viewModel)
                            }

                            if (selectedOption != null) {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(20.dp),
                                    colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else Color.White),
                                    border = BorderStroke(1.dp, RoyalBlue.copy(alpha = 0.2f))
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Lightbulb, "Explanation", tint = GoldAccent, modifier = Modifier.size(20.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Explanation", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = RoyalBlue)
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = currentQuestion.explanation,
                                            fontSize = 14.sp,
                                            lineHeight = 20.sp,
                                            color = if (isDark) Color.LightGray else Color.DarkGray
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            NavigationControlRow(currentIndex, questions, selectedOption, context, viewModel)
                        }
                    }

                    // Pause Overlay
                    if (!isTimerActive) {
                        PauseOverlay(isDark, viewModel)
                    }
                }
            } else {
                // Practice Completion Results Screen (Responsive Container)
                val correctCount = viewModel.getCorrectAnswersCount()
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth(if (LocalConfiguration.current.screenWidthDp >= 600) 0.65f else 1f)
                            .verticalScroll(rememberScrollState()),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.EmojiEvents, "Complete", tint = GoldAccent, modifier = Modifier.size(70.dp))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Practice Completed!", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Accuracy: ${(correctCount * 100) / questions.size}%", fontSize = 16.sp, color = EmeraldGreen, fontWeight = FontWeight.Bold)

                            Spacer(modifier = Modifier.height(24.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Correct", fontSize = 12.sp, color = Color.Gray)
                                    Text("$correctCount", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = EmeraldGreen)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Incorrect", fontSize = 12.sp, color = Color.Gray)
                                    Text("${questions.size - correctCount}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.Red)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Time Spent", fontSize = 12.sp, color = Color.Gray)
                                    Text(String.format("%02d:%02d", timerSeconds / 60, timerSeconds % 60), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(24.dp))

                            Button(
                                onClick = { viewModel.navigateBack() },
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Return to Dashboard", color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TimerCard(
    timerSeconds: Int,
    isTimerActive: Boolean,
    isDark: Boolean,
    viewModel: ExamBridgeViewModel
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = if (isDark) GlassCardDark else Color.White,
                shape = RoundedCornerShape(16.dp)
            )
            .border(
                width = 1.dp,
                color = if (isDark) Color.White.copy(alpha = 0.1f) else Color.Black.copy(alpha = 0.05f),
                shape = RoundedCornerShape(16.dp)
            )
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Timer,
                contentDescription = "Timer",
                tint = GoldAccent,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = String.format("%02d:%02d", timerSeconds / 60, timerSeconds % 60),
                fontWeight = FontWeight.Bold,
                color = if (isDark) Color.White else Color.Black,
                fontSize = 16.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        IconButton(
            onClick = { viewModel.isPracticeTimerActive.value = !isTimerActive },
            modifier = Modifier
                .size(32.dp)
                .background(
                    color = if (isTimerActive) GoldAccent.copy(alpha = 0.15f) else EmeraldGreen.copy(alpha = 0.15f),
                    shape = CircleShape
                )
        ) {
            Icon(
                imageVector = if (isTimerActive) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isTimerActive) "Pause" else "Play",
                tint = if (isTimerActive) GoldAccent else EmeraldGreen,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
fun QuestionNavigationRow(
    currentIndex: Int,
    questions: List<Question>,
    answers: Map<Int, String>,
    bookmarkedIds: Set<Int>,
    isDark: Boolean,
    viewModel: ExamBridgeViewModel
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Progress Tracker",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray
            )
            Text(
                text = "Question ${currentIndex + 1} of ${questions.size}",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = RoyalBlue
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 4.dp)
        ) {
            items(count = questions.size) { index ->
                val q = questions[index]
                val ans = answers[index]
                val isCurrent = index == currentIndex
                val isCorrect = ans != null && ans == q.correctAnswer
                val isIncorrect = ans != null && ans != q.correctAnswer
                val isAnswered = ans != null
                val isBookmarkedQuestion = bookmarkedIds.contains(q.id)

                val bgColor = when {
                    isCurrent -> RoyalBlue
                    isCorrect -> EmeraldGreen
                    isIncorrect -> Color.Red
                    isAnswered -> Color.DarkGray
                    else -> if (isDark) GlassCardDark else Color.LightGray.copy(alpha = 0.5f)
                }

                val contentColor = when {
                    isCurrent || isCorrect || isIncorrect || isAnswered -> Color.White
                    else -> if (isDark) Color.LightGray else Color.Black
                }

                val borderColor = if (isBookmarkedQuestion) GoldAccent else Color.Transparent

                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(bgColor)
                        .border(
                            width = if (isBookmarkedQuestion) 2.dp else 0.dp,
                            color = borderColor,
                            shape = CircleShape
                        )
                        .clickable { viewModel.currentQuestionIndex.value = index },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${index + 1}",
                        color = contentColor,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun OptionsList(
    options: List<Pair<String, String>>,
    selectedOption: String?,
    currentQuestion: Question,
    isDark: Boolean,
    currentIndex: Int,
    viewModel: ExamBridgeViewModel
) {
    options.forEach { (key, optionText) ->
        val isSelected = selectedOption == key
        val isAnswered = selectedOption != null
        val isCorrect = key == currentQuestion.correctAnswer
        val isUserChoice = key == selectedOption

        val cardColor = when {
            !isAnswered -> if (isDark) GlassCardDark else Color.White
            isCorrect -> EmeraldGreen.copy(alpha = if (isDark) 0.15f else 0.12f)
            isUserChoice && !isCorrect -> Color.Red.copy(alpha = if (isDark) 0.15f else 0.1f)
            else -> (if (isDark) GlassCardDark else Color.White).copy(alpha = 0.4f)
        }

        val borderColor = when {
            !isAnswered -> if (isSelected) RoyalBlue else Color.Gray.copy(alpha = 0.2f)
            isCorrect -> EmeraldGreen
            isUserChoice && !isCorrect -> Color.Red
            else -> Color.Gray.copy(alpha = 0.1f)
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(enabled = !isAnswered) {
                    viewModel.submitAnswer(currentIndex, key)
                }
                .border(
                    width = if (isSelected || isCorrect || (isUserChoice && !isCorrect)) 2.dp else 1.dp,
                    color = borderColor,
                    shape = RoundedCornerShape(16.dp)
                ),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = cardColor)
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isCorrect -> EmeraldGreen
                                isUserChoice && !isCorrect -> Color.Red
                                isSelected -> RoyalBlue
                                else -> Color.Gray.copy(alpha = 0.2f)
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isCorrect) {
                        Icon(Icons.Default.Check, "Correct", tint = Color.White, modifier = Modifier.size(16.dp))
                    } else if (isUserChoice && !isCorrect) {
                        Icon(Icons.Default.Close, "Incorrect", tint = Color.White, modifier = Modifier.size(16.dp))
                    } else {
                        Text(key, color = if (isDark) Color.White else Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = optionText,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (!isAnswered) {
                        if (isDark) Color.White else Color.Black
                    } else {
                        if (isCorrect) {
                            if (isDark) Color.White else EmeraldGreen
                        } else if (isUserChoice) {
                            Color.Red
                        } else {
                            Color.Gray
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun NavigationControlRow(
    currentIndex: Int,
    questions: List<Question>,
    selectedOption: String?,
    context: android.content.Context,
    viewModel: ExamBridgeViewModel
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Button(
            onClick = { if (currentIndex > 0) viewModel.currentQuestionIndex.value-- },
            enabled = currentIndex > 0,
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Gray.copy(alpha = 0.2f),
                disabledContainerColor = Color.Gray.copy(alpha = 0.1f)
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Previous", modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Previous", color = MaterialTheme.colorScheme.onSurface)
        }

        Spacer(modifier = Modifier.width(16.dp))

        Button(
            onClick = {
                if (selectedOption != null) {
                    if (currentIndex < questions.size - 1) {
                        viewModel.currentQuestionIndex.value++
                    } else {
                        viewModel.completePractice()
                    }
                } else {
                    Toast.makeText(context, "Please choose an answer or skip", Toast.LENGTH_SHORT).show()
                }
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = if (currentIndex == questions.size - 1) EmeraldGreen else RoyalBlue
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            Text(if (currentIndex == questions.size - 1) "Finish" else "Next", color = Color.White)
            Spacer(modifier = Modifier.width(4.dp))
            Icon(Icons.Default.ArrowForward, contentDescription = "Next", modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
fun PauseOverlay(
    isDark: Boolean,
    viewModel: ExamBridgeViewModel
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                color = (if (isDark) DeepDarkSlate else LightBg).copy(alpha = 0.95f)
            )
            .clickable(enabled = true, onClick = {}), // Absorb taps
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isDark) GlassCardDark else Color.White
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Timer,
                    contentDescription = "Paused",
                    tint = GoldAccent,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Practice Paused",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = if (isDark) Color.White else Color.Black
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Take a breath. Your progress and timer are securely paused.",
                    fontSize = 14.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { viewModel.isPracticeTimerActive.value = true },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Resume Practice", color = Color.White)
                }
            }
        }
    }
}

// ==========================================
// 2. MOCK EXAM SIMULATOR
// ==========================================
@Composable
fun MockCenterScreen(
    viewModel: ExamBridgeViewModel,
    isDark: Boolean
) {
    val questions by viewModel.practiceQuestions.collectAsState()
    val currentIndex by viewModel.currentQuestionIndex.collectAsState()
    val timerSeconds by viewModel.mockTimerSeconds.collectAsState()
    val answers by viewModel.userAnswers.collectAsState()
    val isSubmitted by viewModel.isMockSubmitted.collectAsState()

    val context = LocalContext.current

    if (questions.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = RoyalBlue)
        }
        return
    }

    val currentQuestion = questions[currentIndex]
    val selectedOption = answers[currentIndex]

    Scaffold(
        topBar = {
            AppHeader(
                title = viewModel.mockExamType.value,
                onMenuClick = {},
                onThemeToggle = {},
                isDark = isDark,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = if (isDark) DeepDarkSlate else LightBg
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val isTablet = maxWidth >= 720.dp
            val correctCount = viewModel.getCorrectAnswersCount()

            if (!isSubmitted) {
                if (isTablet) {
                    // --- Tablet / Landscape Responsive Dual Pane Layout ---
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(20.dp),
                        horizontalArrangement = Arrangement.spacedBy(24.dp)
                    ) {
                        // Left Pane: Question content & timer details
                        Column(
                            modifier = Modifier
                                .weight(1.2f)
                                .fillMaxHeight(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Standard Exam Platform • #${currentIndex + 1}", fontSize = 14.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Schedule, "Time Left", tint = Color.Red, modifier = Modifier.size(20.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = String.format("%02d:%02d", timerSeconds / 60, timerSeconds % 60),
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Red,
                                            fontSize = 18.sp
                                        )
                                    }
                                }

                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 16.dp),
                                    shape = RoundedCornerShape(24.dp),
                                    colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight),
                                    border = BorderStroke(1.dp, if (isDark) GlassBorderDark else GlassBorderLight)
                                ) {
                                    Column(modifier = Modifier.padding(28.dp)) {
                                        Text("Question Content:", fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            text = currentQuestion.questionText,
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold,
                                            lineHeight = 26.sp,
                                            color = if (isDark) Color.White else Color.Black
                                        )
                                    }
                                }
                            }

                            // Toolbar Controls
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = { if (currentIndex > 0) viewModel.currentQuestionIndex.value-- },
                                    enabled = currentIndex > 0,
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Gray.copy(alpha = 0.3f)),
                                    modifier = Modifier.testTag("mock_back_button")
                                ) {
                                    Text("Back", color = Color.White)
                                }

                                Button(
                                    onClick = {
                                        if (currentIndex < questions.size - 1) {
                                            viewModel.currentQuestionIndex.value++
                                        } else {
                                            viewModel.submitMockExam()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = if (currentIndex == questions.size - 1) GoldAccent else RoyalBlue),
                                    modifier = Modifier.testTag("mock_next_button")
                                ) {
                                    Text(if (currentIndex == questions.size - 1) "SUBMIT EXAM" else "Next Question", color = Color.White)
                                }
                            }
                        }

                        // Right Pane: Option list
                        Column(
                            modifier = Modifier
                                .weight(1.0f)
                                .fillMaxHeight()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Text("Select Correct Option:", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Gray, modifier = Modifier.padding(bottom = 6.dp))
                            val options = listOf(
                                "A" to currentQuestion.optionA,
                                "B" to currentQuestion.optionB,
                                "C" to currentQuestion.optionC,
                                "D" to currentQuestion.optionD
                            )

                            options.forEach { (key, valText) ->
                                val isSelected = selectedOption == key
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("mock_option_${key}")
                                        .clickable { viewModel.submitAnswer(currentIndex, key) }
                                        .border(
                                            width = if (isSelected) 2.dp else 1.dp,
                                            color = if (isSelected) GoldAccent else Color.Gray.copy(alpha = 0.3f),
                                            shape = RoundedCornerShape(16.dp)
                                        ),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = if (isSelected) GoldAccent.copy(alpha = 0.12f) else Color.Transparent)
                                ) {
                                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(32.dp)
                                                .clip(CircleShape)
                                                .background(if (isSelected) GoldAccent else Color.Gray.copy(alpha = 0.3f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(key, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        }
                                        Spacer(modifier = Modifier.width(16.dp))
                                        Text(valText, fontSize = 15.sp, color = if (isDark) Color.White else Color.Black)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // --- Mobile Portrait Layout ---
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Header details
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Standard Exam Platform • #${currentIndex + 1}", fontSize = 14.sp, color = Color.Gray)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Schedule, "Time Left", tint = Color.Red)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = String.format("%02d:%02d", timerSeconds / 60, timerSeconds % 60),
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Red,
                                    fontSize = 16.sp
                                )
                            }
                        }

                        // Question Box
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                                .padding(vertical = 12.dp),
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight)
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Text("Question Content:", fontSize = 12.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(currentQuestion.questionText, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Options
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            val options = listOf(
                                "A" to currentQuestion.optionA,
                                "B" to currentQuestion.optionB,
                                "C" to currentQuestion.optionC,
                                "D" to currentQuestion.optionD
                            )

                            options.forEach { (key, valText) ->
                                val isSelected = selectedOption == key
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("mock_option_${key}")
                                        .clickable { viewModel.submitAnswer(currentIndex, key) }
                                        .border(
                                            width = if (isSelected) 2.dp else 1.dp,
                                            color = if (isSelected) GoldAccent else Color.Gray.copy(alpha = 0.3f),
                                            shape = RoundedCornerShape(16.dp)
                                        ),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = if (isSelected) GoldAccent.copy(alpha = 0.1f) else Color.Transparent)
                                ) {
                                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(26.dp)
                                                .clip(CircleShape)
                                                .background(if (isSelected) GoldAccent else Color.Gray.copy(alpha = 0.3f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(key, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Text(valText, fontSize = 14.sp)
                                    }
                                }
                            }
                        }

                        // Toolbar Controls
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = { if (currentIndex > 0) viewModel.currentQuestionIndex.value-- },
                                enabled = currentIndex > 0,
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Gray.copy(alpha = 0.3f)),
                                modifier = Modifier.testTag("mock_back_button")
                            ) {
                                Text("Back", color = Color.White)
                            }

                            Button(
                                onClick = {
                                    if (currentIndex < questions.size - 1) {
                                        viewModel.currentQuestionIndex.value++
                                    } else {
                                        viewModel.submitMockExam()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = if (currentIndex == questions.size - 1) GoldAccent else RoyalBlue),
                                modifier = Modifier.testTag("mock_next_button")
                            ) {
                                Text(if (currentIndex == questions.size - 1) "SUBMIT EXAM" else "Next Question", color = Color.White)
                            }
                        }
                    }
                }
            } else {
                // --- Results Screen (Centered/Constrained for Desktop & Fullscreen) ---
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth(if (isTablet) 0.6f else 1.0f)
                            .verticalScroll(rememberScrollState()),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight),
                        border = BorderStroke(1.dp, if (isDark) GlassBorderDark else GlassBorderLight)
                    ) {
                        Column(
                            modifier = Modifier.padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.VerifiedUser, "Success", tint = EmeraldGreen, modifier = Modifier.size(72.dp))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Exam Submitted Successfully!", fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Accuracy Score: ${(correctCount * 100) / questions.size}%", fontSize = 18.sp, color = GoldAccent, fontWeight = FontWeight.Bold)

                            Spacer(modifier = Modifier.height(20.dp))
                            Divider()
                            Spacer(modifier = Modifier.height(20.dp))

                            Text("Mock Admission Rank: #${(20..130).random()}", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Your score qualifies you within the top tier pool of university entrants.", fontSize = 13.sp, color = Color.Gray, textAlign = TextAlign.Center)

                            Spacer(modifier = Modifier.height(28.dp))
                            Button(
                                onClick = { viewModel.navigateBack() },
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("mock_return_home_button")
                            ) {
                                Text("Return Home", color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 3. ANALYTICS REPORTS
// ==========================================
@Composable
fun AnalyticsScreen(
    viewModel: ExamBridgeViewModel,
    isDark: Boolean
) {
    Scaffold(
        topBar = {
            AppHeader(
                title = "Analytics Dashboard",
                onMenuClick = {},
                onThemeToggle = {},
                isDark = isDark,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = if (isDark) DeepDarkSlate else LightBg
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("Performance Timeline (Accuracy)", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight)
                ) {
                    PerformanceLineChart(isDark)
                }
            }

            item {
                Text("Monthly Activity (Hours Study)", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight)
                ) {
                    MonthlyBarChart(isDark)
                }
            }

            item {
                Text("Study Metrics Summary", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }

            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    PremiumStatisticCard(
                        modifier = Modifier.weight(1f),
                        title = "Study Streak",
                        value = "35 Days",
                        desc = "Keep it up!",
                        icon = Icons.Default.LocalFireDepartment,
                        color = GoldAccent,
                        isDark = isDark
                    )
                    PremiumStatisticCard(
                        modifier = Modifier.weight(1f),
                        title = "Accuracy",
                        value = "84.5%",
                        desc = "Above Average",
                        icon = Icons.Default.CheckCircle,
                        color = EmeraldGreen,
                        isDark = isDark
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    PremiumStatisticCard(
                        modifier = Modifier.weight(1f),
                        title = "Questions Solved",
                        value = "1,250",
                        desc = "Total practiced",
                        icon = Icons.Default.Task,
                        color = RoyalBlue,
                        isDark = isDark
                    )
                    PremiumStatisticCard(
                        modifier = Modifier.weight(1f),
                        title = "Mock Exams",
                        value = "14",
                        desc = "Completed",
                        icon = Icons.Default.Assignment,
                        color = SecondaryBlue,
                        isDark = isDark
                    )
                }
            }
        }
    }
}

// ==========================================
// 4. PREMIUM PAYMENT FLOW
// ==========================================
@Composable
fun OldPremiumUpgradeScreen(
    viewModel: ExamBridgeViewModel,
    profile: UserProfile,
    isDark: Boolean
) {
    val reqState by viewModel.premiumRequest.collectAsState(initial = null)
    var selectedMethod by remember { mutableStateOf("CBE") }
    var txIdInput by remember { mutableStateOf("") }

    val context = LocalContext.current

    val paymentMethods = listOf("CBE", "Abbay Bank", "Abyssinia Bank", "Awash Bank", "CBEbirr", "Telebirr")

    Scaffold(
        topBar = {
            AppHeader(
                title = "Upgrade to Premium",
                onMenuClick = {},
                onThemeToggle = {},
                isDark = isDark,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = if (isDark) DeepDarkSlate else LightBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Advantage Card
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SoftBrandBlue),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.WorkspacePremium, "Premium", tint = GoldAccent, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("PREMIUM YEARLY MEMBER", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Unlock everything you need to score maximum values on the university exams:", color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    val perks = listOf(
                        "Unlimited Questions & Mock Exams",
                        "Smart Offline Caching & Full Sync",
                        "Complete PDF Notes & Video Playlists",
                        "Detailed Performance Reports",
                        "Priority Admin Support"
                    )
                    perks.forEach { perk ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                            Icon(Icons.Default.Check, "Checked", tint = GoldAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(perk, color = Color.White, fontSize = 12.sp)
                        }
                    }
                }
            }

            if (reqState == null) {
                // Payment Steps Interface
                Text("STEP 1: Select Payment Method", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    paymentMethods.forEach { method ->
                        val selected = selectedMethod == method
                        Box(
                            modifier = Modifier
                                .background(
                                    if (selected) RoyalBlue else SoftBrandBlue.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { selectedMethod = method }
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                        ) {
                            Text(method, color = if (selected) Color.White else (if (isDark) Color.White else Color.Black), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }

                Text("STEP 2: Send Money & Copy Details", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Account Name: Exam Bridge EdTech", fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        val accNo = when (selectedMethod) {
                            "CBE" -> "1000341890214"
                            "Telebirr" -> "0911234567"
                            "CBEbirr" -> "0911234567"
                            else -> "9012345671"
                        }
                        CopyableInfoItem(label = "Official $selectedMethod Account", value = accNo, isDark = isDark)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Amount Due: 450 ETB (Yearly Subscription)", color = GoldAccent, fontWeight = FontWeight.Bold)
                    }
                }

                Text("STEP 3: Enter Proof of Payment", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = txIdInput,
                    onValueChange = { txIdInput = it },
                    label = { Text("Transaction ID / Reference Number") },
                    leadingIcon = { Icon(Icons.Default.Label, "Tx") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                )

                Button(
                    onClick = {
                        if (txIdInput.isNotBlank()) {
                            viewModel.submitPaymentVerification(selectedMethod, txIdInput)
                            Toast.makeText(context, "Verification Submitted!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Please enter your Transaction ID", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                ) {
                    Text("Submit Verification", color = Color.White, fontWeight = FontWeight.Bold)
                }
            } else {
                // Request Pending or Processed State
                val status = reqState?.status ?: "PENDING"
                val statusColor = when (status) {
                    "APPROVED" -> EmeraldGreen
                    "REJECTED" -> Color.Red
                    else -> GoldAccent
                }

                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.HourglassEmpty, "Pending", tint = statusColor, modifier = Modifier.size(56.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Payment Status: $status", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = statusColor)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Verification Submitted Successfully. Payment review will be completed within 12 hours. Please wait patiently. Thank you",
                            textAlign = TextAlign.Center,
                            fontSize = 13.sp,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Divider()
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Tx Reference: ${reqState?.transactionId}", fontWeight = FontWeight.Bold)
                        Text("Bank: ${reqState?.bankName}", fontSize = 12.sp, color = Color.Gray)
                        if (reqState?.comment?.isNotBlank() == true) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Note: ${reqState?.comment}", color = Color.Red, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PremiumStatisticCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    isDark: Boolean
) {
    val borderColor = if (isDark) GlassBorderDark else color.copy(alpha = 0.3f)
    val containerColor = if (isDark) GlassCardDark else Color.White
    
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isDark) 0.dp else 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = title, tint = color, modifier = Modifier.size(18.dp))
                }
                Text(desc, fontSize = 10.sp, color = if (isDark) Color.LightGray else Color(0xFF6B7280))
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(value, fontWeight = FontWeight.Bold, fontSize = 22.sp, color = if (isDark) Color.White else Color(0xFF111827))
            Spacer(modifier = Modifier.height(4.dp))
            Text(title, fontSize = 12.sp, color = if (isDark) Color.LightGray else Color(0xFF6B7280))
        }
    }
}
