package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val RoyalBlue = Color(0xFF2563EB)
val EmeraldGreen = Color(0xFF10B981)
val GoldAccent = Color(0xFFF59E0B)

// Official EXAM BRIDGE Brand Colors
val BrandPrimary = Color(0xFF062238)
val BrandGradientStart = Color(0xFF041B2D)
val BrandGradientMiddle = Color(0xFF062238)
val BrandGradientEnd = Color(0xFF082A43)

val SoftBrandBlue = Color(0xFF6C8DFF)
val DeepDarkSlate = Color(0xFF0F172A)
val RichMidnight = Color(0xFF111827)
val DeepestVoid = Color(0xFF020617)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val GlassCardDark = Color(0x1F475569) // Semi-transparent Slate for glassmorphism
val GlassBorderDark = Color(0x3394A3B8)

val LightBg = Color(0xFFF4F7FC)
val LightSurface = Color(0xFFFFFFFF)
val TextPrimaryLight = Color(0xFF111827)
val TextSecondaryLight = Color(0xFF6B7280)
val GlassCardLight = Color(0xFFFFFFFF)
val GlassBorderLight = Color(0xFFD6E4FF)
val AccentBorderLight = Color(0xFFBFDBFE)
val SecondaryBlue = Color(0xFF3B82F6)

