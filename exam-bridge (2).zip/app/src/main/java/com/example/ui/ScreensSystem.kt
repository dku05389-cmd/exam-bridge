package com.example.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

// ==========================================
// 1. SETTINGS SCREEN
// ==========================================
@Composable
fun SettingsScreen(
    viewModel: ExamBridgeViewModel,
    profile: UserProfile,
    isDark: Boolean
) {
    var editMode by remember { mutableStateOf(false) }
    var nameInput by remember { mutableStateOf(profile.name) }
    var schoolInput by remember { mutableStateOf(profile.school) }

    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    Scaffold(
        topBar = {
            AppHeader(
                title = "Settings",
                onMenuClick = {},
                onThemeToggle = {},
                isDark = isDark,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = if (isDark) DeepDarkSlate else LightBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // 1. Profile Card Top
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight),
                border = BorderStroke(1.dp, if (isDark) GlassBorderDark else GlassBorderLight)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(RoyalBlue, SecondaryBlue))),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, "Avatar", tint = Color.White, modifier = Modifier.size(26.dp))
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                if (editMode) {
                                    OutlinedTextField(
                                        value = nameInput,
                                        onValueChange = { nameInput = it },
                                        modifier = Modifier.width(180.dp),
                                        shape = RoundedCornerShape(12.dp),
                                        singleLine = true,
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = RoyalBlue,
                                            unfocusedBorderColor = if (isDark) Color.DarkGray else Color.LightGray
                                        )
                                    )
                                } else {
                                    Text(
                                        text = profile.name, 
                                        fontWeight = FontWeight.Bold, 
                                        fontSize = 17.sp,
                                        color = if (isDark) Color.White else TextPrimaryLight
                                    )
                                }
                                Text(
                                    text = profile.email, 
                                    fontSize = 12.sp, 
                                    color = if (isDark) TextSecondaryDark else TextSecondaryLight
                                )
                            }
                        }

                        IconButton(
                            onClick = {
                                if (editMode) {
                                    viewModel.updateProfile(nameInput, schoolInput)
                                    editMode = false
                                    Toast.makeText(context, "Profile updated!", Toast.LENGTH_SHORT).show()
                                } else {
                                    editMode = true
                                }
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .background(
                                    color = RoyalBlue.copy(alpha = 0.1f),
                                    shape = CircleShape
                                )
                        ) {
                            Icon(
                                imageVector = if (editMode) Icons.Default.Save else Icons.Default.Edit,
                                contentDescription = "Edit Profile",
                                tint = RoyalBlue,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    if (editMode) {
                        OutlinedTextField(
                            value = schoolInput,
                            onValueChange = { schoolInput = it },
                            label = { Text("School Name") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = RoyalBlue,
                                unfocusedBorderColor = if (isDark) Color.DarkGray else Color.LightGray
                            )
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.School,
                                contentDescription = null,
                                tint = RoyalBlue,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "School: ${profile.school}", 
                                fontSize = 13.sp,
                                color = if (isDark) Color.LightGray else TextPrimaryLight
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    CopyableInfoItem(label = "Student Unique ID (S.ID)", value = profile.studentId, isDark = isDark)
                }
            }

            // 2. Language Picker
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Multi Language System", 
                    fontSize = 15.sp, 
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) Color.White else TextPrimaryLight,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val languages = listOf("English", "Amharic", "Afaan Oromo", "Tigrinya")
                    languages.forEach { lang ->
                        val selected = viewModel.currentLanguage.collectAsState().value == lang
                        val tabBg = if (selected) {
                            Brush.horizontalGradient(listOf(RoyalBlue, SecondaryBlue))
                        } else {
                            Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
                        }
                        
                        val containerBgColor = if (selected) Color.Transparent else (if (isDark) Color(0xFF1E293B) else Color(0xFFF1F5F9))
                        val textAndIconColor = if (selected) Color.White else (if (isDark) Color.LightGray else Color(0xFF4B5563))
                        val borderStrokeColor = if (selected) Color.Transparent else (if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0))

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .shadow(if (selected) 2.dp else 0.dp, RoundedCornerShape(12.dp))
                                .background(containerBgColor, RoundedCornerShape(12.dp))
                                .background(tabBg, RoundedCornerShape(12.dp))
                                .border(1.dp, borderStrokeColor, RoundedCornerShape(12.dp))
                                .clickable { viewModel.setLanguage(lang) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = lang, 
                                fontSize = 11.sp, 
                                fontWeight = FontWeight.Bold, 
                                color = textAndIconColor,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            // 3. Referral link
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Refer & Earn", 
                    fontSize = 15.sp, 
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) Color.White else TextPrimaryLight,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                CopyableInfoItem(label = "Your Referral Link", value = profile.referralLink, isDark = isDark)
            }

            // 4. Academic Stream Change & Preferences Grouped Card
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Academic Preferences", 
                    fontSize = 15.sp, 
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) Color.White else TextPrimaryLight,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight),
                    border = BorderStroke(1.dp, if (isDark) GlassBorderDark else GlassBorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        // Preference 1: Stream Change
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.navigateTo(Screen.StreamSelect) }
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(RoyalBlue.copy(alpha = 0.1f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.School, 
                                        contentDescription = null, 
                                        tint = RoyalBlue, 
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Change Academic Stream", 
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = if (isDark) Color.White else TextPrimaryLight
                                    )
                                    Text(
                                        text = "Current: ${profile.stream}", 
                                        fontSize = 11.sp,
                                        color = if (isDark) TextSecondaryDark else TextSecondaryLight
                                    )
                                }
                            }
                            Icon(
                                imageVector = Icons.Default.ChevronRight, 
                                contentDescription = "Navigate", 
                                tint = Color.Gray,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        HorizontalDivider(
                            color = if (isDark) Color.White.copy(alpha = 0.08f) else Color(0xFFF1F5F9),
                            thickness = 1.dp,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )

                        // Preference 2: System Items List (About Us, Rate App, Admin Panel)
                        val extraItems = listOf(
                            Triple("About Us", Icons.Default.Info, RoyalBlue),
                            Triple("Rate Application", Icons.Default.ThumbUp, EmeraldGreen),
                            Triple("Admin Dashboard Panel", Icons.Default.AdminPanelSettings, GoldAccent)
                        )

                        extraItems.forEachIndexed { index, (label, icon, color) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (label.contains("Admin")) {
                                            viewModel.navigateTo(Screen.AdminDashboard)
                                        } else {
                                            Toast.makeText(context, "Clicked: $label", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(color.copy(alpha = 0.1f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(icon, label, tint = color, modifier = Modifier.size(18.dp))
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = label, 
                                        fontWeight = FontWeight.Bold, 
                                        fontSize = 14.sp,
                                        color = if (isDark) Color.White else TextPrimaryLight
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.ChevronRight, 
                                    contentDescription = "Navigate", 
                                    tint = Color.Gray,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            if (index < extraItems.lastIndex) {
                                HorizontalDivider(
                                    color = if (isDark) Color.White.copy(alpha = 0.08f) else Color(0xFFF1F5F9),
                                    thickness = 1.dp,
                                    modifier = Modifier.padding(horizontal = 16.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 5. Beautiful Logout Button
            Button(
                onClick = { viewModel.logout() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isDark) Color(0xFFDC2626).copy(alpha = 0.15f) else Color(0xFFFEF2F2),
                    contentColor = Color(0xFFEF4444)
                ),
                border = BorderStroke(1.dp, if (isDark) Color(0xFFEF4444).copy(alpha = 0.3f) else Color(0xFFFEE2E2)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 14.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Logout,
                    contentDescription = "Logout",
                    tint = Color(0xFFEF4444),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Log Out", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }
}

@Composable
fun ProfileTabContent(
    viewModel: ExamBridgeViewModel,
    profile: UserProfile,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Profile Info Header
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight),
            border = BorderStroke(1.dp, if (isDark) GlassBorderDark else GlassBorderLight)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(70.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(RoyalBlue, GoldAccent))),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = profile.name.take(2).uppercase(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(profile.name, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = if (isDark) Color.White else Color.Black)
                Text("Student ID: ${profile.studentId}", fontSize = 12.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .background(EmeraldGreen.copy(alpha = 0.2f), shape = RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(profile.stream, color = EmeraldGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Stats row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight),
                border = BorderStroke(1.dp, if (isDark) GlassBorderDark else GlassBorderLight)
            ) {
                Column(modifier = Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("XP Points", fontSize = 11.sp, color = Color.Gray)
                    Text("${profile.points}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = RoyalBlue)
                }
            }
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight),
                border = BorderStroke(1.dp, if (isDark) GlassBorderDark else GlassBorderLight)
            ) {
                Column(modifier = Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Active Streak", fontSize = 11.sp, color = Color.Gray)
                    Text("${profile.streakDays} Days", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = GoldAccent)
                }
            }
        }

        // Achievements List
        Text("Achievements Badges", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = if (isDark) Color.White else Color.Black)

        val badges = listOf(
            Triple("First Exam Completed", "Awarded for passing your very first mockup exam.", Icons.Default.CheckCircle),
            Triple("100 Questions Solved", "Solved 100+ entrance practice questions.", Icons.Default.LocalFireDepartment),
            Triple("7-Day Active Streak", "Studied 7 days in a row with zero breaks.", Icons.Default.CalendarToday),
            Triple("Top Performer Badge", "Achieved score greater than 90% accuracy.", Icons.Default.WorkspacePremium)
        )

        badges.forEach { (title, desc, icon) ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight),
                border = BorderStroke(1.dp, if (isDark) GlassBorderDark else GlassBorderLight)
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(GoldAccent.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, title, tint = GoldAccent)
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = if (isDark) Color.White else Color.Black)
                        Text(desc, fontSize = 12.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

// ==========================================
// 2. PROFILE & ACHIEVEMENTS SCREEN
// ==========================================
@Composable
fun ProfileScreen(
    viewModel: ExamBridgeViewModel,
    profile: UserProfile,
    isDark: Boolean
) {
    Scaffold(
        topBar = {
            AppHeader(
                title = "Student Profile",
                onMenuClick = {},
                onThemeToggle = {},
                isDark = isDark,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = if (isDark) DeepDarkSlate else LightBg
    ) { innerPadding ->
        ProfileTabContent(
            viewModel = viewModel,
            profile = profile,
            isDark = isDark,
            modifier = Modifier.padding(innerPadding)
        )
    }
}

// ==========================================
// 3. VIDEO LESSONS SCREEN
// ==========================================
@Composable
fun VideosScreen(
    viewModel: ExamBridgeViewModel,
    isDark: Boolean
) {
    val currentVideo by viewModel.currentPlayingVideo.collectAsState()
    val isPlaying by viewModel.isVideoPlaying.collectAsState()

    val playlists = listOf("Biology Core", "Physics Electromagnetism", "Chemistry Compounds", "English Grammar", "Aptitude Tricks")

    Scaffold(
        topBar = {
            AppHeader(
                title = "Video Academy",
                onMenuClick = {},
                onThemeToggle = {},
                isDark = isDark,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = if (isDark) DeepDarkSlate else LightBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Simulated Player Box
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Black)
            ) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                            contentDescription = "Play/Pause",
                            tint = Color.White,
                            modifier = Modifier
                                .size(64.dp)
                                .clickable { viewModel.isVideoPlaying.value = !isPlaying }
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(currentVideo, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(if (isPlaying) "Streaming Standard Quality..." else "Video Paused", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }

            Text("Browse Playlists", fontSize = 18.sp, fontWeight = FontWeight.Bold)

            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(playlists) { listName ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.currentPlayingVideo.value = "$listName: Chapter 1 Video Guide"
                                viewModel.isVideoPlaying.value = true
                            },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PlaylistPlay, "Playlist", tint = RoyalBlue)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(listName, fontWeight = FontWeight.Bold)
                            }
                            Icon(Icons.Default.PlayArrow, "Play", tint = EmeraldGreen)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 4. LEADERBOARD SCREEN
// ==========================================
@Composable
fun LeaderboardScreen(
    viewModel: ExamBridgeViewModel,
    isDark: Boolean
) {
    var selectedCategory by remember { mutableStateOf("Weekly") }

    val ranks = listOf(
        Triple("Dawit Atalo", "EB-SID-734109", 1450),
        Triple("Almaz Kebede", "EB-SID-239102", 1320),
        Triple("Yared Yosef", "EB-SID-901823", 1280),
        Triple("Selam Tilahun", "EB-SID-112390", 1150),
        Triple("Chala Tolosa", "EB-SID-883102", 980)
    )

    Scaffold(
        topBar = {
            AppHeader(
                title = "Leaderboard",
                onMenuClick = {},
                onThemeToggle = {},
                isDark = isDark,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = if (isDark) DeepDarkSlate else LightBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth()) {
                listOf("Weekly", "Monthly").forEach { cat ->
                    val selected = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                if (selected) RoyalBlue else SoftBrandBlue.copy(alpha = 0.2f),
                                shape = if (cat == "Weekly") RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp) else RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp)
                            )
                            .clickable { selectedCategory = cat }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(cat, fontWeight = FontWeight.Bold, color = if (selected) Color.White else (if (isDark) Color.White else Color.Black))
                    }
                }
            }

            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(ranks.indexed()) { (index, item) ->
                    val (name, sid, pts) = item
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(if (index == 0) GoldAccent else RoyalBlue),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("${index + 1}", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(name, fontWeight = FontWeight.Bold)
                                    Text(sid, fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                            Text("$pts XP", color = EmeraldGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. ADMIN PANEL & BULK UPLOAD SYSTEM
// ==========================================
@Composable
fun AdminDashboardScreen(
    viewModel: ExamBridgeViewModel,
    isDark: Boolean
) {
    val requests by viewModel.allPremiumRequests.collectAsState(initial = emptyList())
    var commentInput by remember { mutableStateOf("") }
    val context = LocalContext.current

    Scaffold(
        topBar = {
            AppHeader(
                title = "Admin Control Panel",
                onMenuClick = {},
                onThemeToggle = {},
                isDark = isDark,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        containerColor = if (isDark) DeepDarkSlate else LightBg
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Bulk Upload Card Section
            item {
                Text("Bulk Question Upload System", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight)
                ) {
                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .border(2.dp, RoyalBlue, shape = RoundedCornerShape(16.dp))
                                .background(RoyalBlue.copy(alpha = 0.05f))
                                .clickable {
                                    viewModel.processBulkUploadFile("questions.xlsx", "mock data")
                                    Toast.makeText(context, "Mock questions parsed successfully!", Toast.LENGTH_SHORT).show()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.CloudUpload, "Upload", tint = RoyalBlue, modifier = Modifier.size(36.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Click to Drag & Drop Excel / CSV", fontWeight = FontWeight.Bold)
                                Text("Supports .xlsx, .csv, .json, .docx", fontSize = 11.sp, color = Color.Gray)
                            }
                        }

                        val stats = viewModel.bulkUploadStats.collectAsState().value
                        if (stats != null) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Import Results Preview:", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Success", fontSize = 11.sp, color = Color.Gray)
                                    Text("${stats.successfullyImported}", fontWeight = FontWeight.Bold, color = EmeraldGreen)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Failed", fontSize = 11.sp, color = Color.Gray)
                                    Text("${stats.failed}", fontWeight = FontWeight.Bold, color = Color.Red)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Duplicates", fontSize = 11.sp, color = Color.Gray)
                                    Text("${stats.duplicates}", fontWeight = FontWeight.Bold, color = GoldAccent)
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = {
                                    viewModel.importBulkQuestions()
                                    Toast.makeText(context, "All parsed questions committed to DB!", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Commit Import to Question Bank", color = Color.White)
                            }
                        }
                    }
                }
            }

            // Pending Verification Requests
            item {
                Text("Pending Premium Verification Requests", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }

            if (requests.isEmpty()) {
                item {
                    Text("No pending request submissions at this time.", color = Color.Gray, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                }
            } else {
                items(requests) { req ->
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isDark) GlassCardDark else GlassCardLight)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Student ID: ${req.studentId}", fontWeight = FontWeight.Bold)
                            Text("Bank Chosen: ${req.bankName}", fontSize = 13.sp)
                            Text("Transaction: ${req.transactionId}", fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = commentInput,
                                onValueChange = { commentInput = it },
                                label = { Text("Admin Decision Comment") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Button(
                                    onClick = {
                                        viewModel.adminApproveRequest(req.studentId, commentInput)
                                        Toast.makeText(context, "Subscription approved!", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Approve", color = Color.White)
                                }

                                Button(
                                    onClick = {
                                        viewModel.adminRejectRequest(req.studentId, commentInput)
                                        Toast.makeText(context, "Subscription rejected!", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Reject", color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Helpers
fun <T> List<T>.indexed(): List<IndexedValue<T>> = this.withIndex().toList()
