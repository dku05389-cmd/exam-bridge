package com.example.ui

import android.app.Application
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

sealed class Screen {
    object Splash : Screen()
    object Onboarding : Screen()
    object Auth : Screen()
    object StreamSelect : Screen()
    object Dashboard : Screen() // Sub-tabs: Home (0), Exams (1), UEE (2), Notes (3)
    object Practice : Screen()
    object MockCenter : Screen()
    object Analytics : Screen()
    object Videos : Screen()
    object Leaderboard : Screen()
    object PremiumUpgrade : Screen()
    object Settings : Screen()
    object Profile : Screen()
    object AdminDashboard : Screen()
    object Notifications : Screen()
}

class ExamBridgeViewModel(application: Application) : AndroidViewModel(application) {

    private val db = ExamBridgeDatabase.getDatabase(application)
    private val repository = ExamBridgeRepository(db)

    // --- Navigation & Header ---
    val currentScreen = MutableStateFlow<Screen>(Screen.Splash)
    val dashboardTab = MutableStateFlow(0) // 0: Home, 1: Exams, 2: UEE, 3: Notes, 4: Profile
    val backStack = mutableStateListOf<Screen>()

    // Drawer control
    val isDrawerOpen = MutableStateFlow(false)

    // --- Application Config ---
    val currentLanguage = MutableStateFlow(Translations.LANG_EN)
    val isDarkMode = MutableStateFlow(true) // Default to beautiful modern dark theme
    val isOnline = MutableStateFlow(true)   // Online vs Offline simulation

    // --- Data Streams ---
    val userProfile = repository.getUserProfileFlow()
    val allQuestions = repository.getAllQuestionsFlow()
    val allMockResults = repository.getAllResultsFlow()
    val premiumRequest = repository.getRequestFlow()
    val allPremiumRequests = repository.getAllRequestsFlow()
    val offlineDownloads = repository.getAllDownloadsFlow()

    // --- Active Practice / Exam States ---
    val activeSubject = MutableStateFlow("Biology")
    val activeTopic = MutableStateFlow("All Topics")
    val practiceQuestions = MutableStateFlow<List<Question>>(emptyList())
    val currentQuestionIndex = MutableStateFlow(0)
    val practiceTimerSeconds = MutableStateFlow(0)
    val isPracticeTimerActive = MutableStateFlow(false)
    val userAnswers = MutableStateFlow<Map<Int, String>>(emptyMap()) // Index -> Option
    val bookmarkedIds = MutableStateFlow<Set<Int>>(emptySet())
    val showPracticeResults = MutableStateFlow(false)
    val selectedStreamFilter = MutableStateFlow("Natural Science")

    // --- Mock Exam Session State ---
    val mockExamType = MutableStateFlow("Full Entrance Exam")
    val mockTimerSeconds = MutableStateFlow(7200) // 2 hours
    val isMockTimerActive = MutableStateFlow(false)
    val isMockSubmitted = MutableStateFlow(false)

    // --- Video State ---
    val activeVideoPlaylist = MutableStateFlow("Biology Core")
    val currentPlayingVideo = MutableStateFlow("Video 1: Intro to Cytology")
    val isVideoPlaying = MutableStateFlow(false)
    val watchHistory = MutableStateFlow<List<String>>(listOf("Intro to Cells", "Newtonian Force Principles"))

    // --- Notification List ---
    val inAppNotifications = MutableStateFlow<List<AppNotification>>(emptyList())

    // --- Admin Question Upload (Bulk) ---
    val bulkUploadPreviewList = MutableStateFlow<List<Question>>(emptyList())
    val bulkUploadStats = MutableStateFlow<BulkUploadStats?>(null)

    init {
        // Run initial seed and load notifications
        viewModelScope.launch {
            // Seed questions if database is empty
            repository.getAllQuestionsFlow().first().let { list ->
                if (list.isEmpty()) {
                    repository.insertQuestions(QuestionSeeder.getSeedQuestions())
                }
            }

            // Sync settings when profile loads
            userProfile.collect { profile ->
                if (profile != null) {
                    currentLanguage.value = profile.language
                    isDarkMode.value = profile.isNotificationsEnabled // use notification toggle as simple persistence or separate setting
                    if (profile.stream != "None") {
                        selectedStreamFilter.value = profile.stream
                    }
                }
            }
        }

        // Generate dummy notifications
        generateSampleNotifications()

        // Splash screen 3s delay
        viewModelScope.launch {
            delay(3000)
            val profile = repository.getUserProfile()
            if (profile == null) {
                currentScreen.value = Screen.Onboarding
            } else if (profile.stream == "None") {
                currentScreen.value = Screen.StreamSelect
            } else {
                currentScreen.value = Screen.Dashboard
            }
        }

        // Practice Timer increment loop
        viewModelScope.launch {
            while (true) {
                delay(1000)
                if (isPracticeTimerActive.value) {
                    practiceTimerSeconds.value += 1
                }
                if (isMockTimerActive.value && mockTimerSeconds.value > 0) {
                    mockTimerSeconds.value -= 1
                    if (mockTimerSeconds.value == 0) {
                        submitMockExam()
                    }
                }
            }
        }
    }

    // --- Navigation Helpers ---
    fun navigateTo(screen: Screen) {
        if (currentScreen.value != screen) {
            backStack.add(currentScreen.value)
            currentScreen.value = screen
        }
        isDrawerOpen.value = false
    }

    fun navigateBack() {
        if (backStack.isNotEmpty()) {
            val prev = backStack.removeAt(backStack.size - 1)
            currentScreen.value = prev
        } else {
            // If empty, fall back to Dashboard or Auth
            currentScreen.value = Screen.Dashboard
        }
    }

    fun setDashboardTab(tab: Int) {
        dashboardTab.value = tab
        currentScreen.value = Screen.Dashboard
        isDrawerOpen.value = false
    }

    // --- Authentication ---
    fun login(emailInput: String, passwordInput: String, rememberMe: Boolean, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            // Since we are offline-first and simulation, let's check if there's any registered user
            val existing = repository.getUserProfile()
            if (existing != null && emailInput.isNotBlank()) {
                // Successful login
                onSuccess()
                if (existing.stream == "None") {
                    currentScreen.value = Screen.StreamSelect
                } else {
                    currentScreen.value = Screen.Dashboard
                }
            } else if (emailInput.isNotBlank()) {
                // If profile doesn't exist, register a placeholder or error
                val randomId = "EB-SID-${(100000..999999).random()}"
                val randomRef = "https://exambridge.edu/ref/EB-REF-${(100000..999999).random()}"
                val newProfile = UserProfile(
                    studentId = randomId,
                    name = emailInput.substringBefore("@").replaceFirstChar { it.uppercase() },
                    email = emailInput,
                    phone = "+251911234567",
                    school = "Bole High School",
                    stream = "None",
                    isPremium = "FREE",
                    registrationDate = getCurrentDateString(),
                    joinedDate = "N/A",
                    referralLink = randomRef,
                    points = 250,
                    streakDays = 35,
                    dailyGoalHours = 2.0f,
                    avatarId = 1,
                    language = currentLanguage.value
                )
                repository.insertOrUpdateProfile(newProfile)
                onSuccess()
                currentScreen.value = Screen.StreamSelect
            } else {
                onError("Please enter email and password.")
            }
        }
    }

    fun register(name: String, email: String, phone: String, school: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val randomId = "EB-SID-${(100000..999999).random()}"
            val randomRef = "https://exambridge.edu/ref/EB-REF-${(100000..999999).random()}"
            val newProfile = UserProfile(
                studentId = randomId,
                name = name.ifBlank { "Success Student" },
                email = email.ifBlank { "student@exambridge.edu" },
                phone = phone.ifBlank { "+251912345678" },
                school = school.ifBlank { "Ethio-National Academy" },
                stream = "None",
                isPremium = "FREE",
                registrationDate = getCurrentDateString(),
                joinedDate = "N/A",
                referralLink = randomRef,
                points = 100,
                streakDays = 1,
                dailyGoalHours = 2.0f,
                avatarId = 2,
                language = currentLanguage.value
            )
            repository.insertOrUpdateProfile(newProfile)
            onSuccess()
            currentScreen.value = Screen.StreamSelect
        }
    }

    fun logout() {
        viewModelScope.launch {
            // For simulation logout, we can just clear backstack and go to Auth
            backStack.clear()
            currentScreen.value = Screen.Auth
        }
    }

    // --- Profile Editing ---
    fun updateProfile(name: String, school: String) {
        viewModelScope.launch {
            val current = repository.getUserProfile()
            if (current != null) {
                repository.updatePersonalInfo(current.studentId, name, school)
            }
        }
    }

    // --- Stream Selection ---
    fun selectStream(stream: String) {
        viewModelScope.launch {
            val current = repository.getUserProfile()
            if (current != null) {
                repository.updateStream(current.studentId, stream)
                currentScreen.value = Screen.Dashboard
            }
        }
    }

    // --- Change Settings ---
    fun setLanguage(lang: String) {
        viewModelScope.launch {
            currentLanguage.value = lang
            val current = repository.getUserProfile()
            if (current != null) {
                repository.insertOrUpdateProfile(current.copy(language = lang))
            }
        }
    }

    fun toggleTheme() {
        isDarkMode.value = !isDarkMode.value
    }

    // --- Practice Mode Control ---
    fun startPractice(subject: String, topic: String = "All Topics") {
        activeSubject.value = subject
        activeTopic.value = topic
        currentQuestionIndex.value = 0
        practiceTimerSeconds.value = 0
        isPracticeTimerActive.value = true
        userAnswers.value = emptyMap()
        showPracticeResults.value = false

        viewModelScope.launch {
            val allQs = repository.getAllQuestionsFlow().first()
            val filtered = allQs.filter {
                it.subject.equals(subject, ignoreCase = true) &&
                        (topic == "All Topics" || it.topic.equals(topic, ignoreCase = true))
            }.shuffled()
            practiceQuestions.value = filtered
            navigateTo(Screen.Practice)
        }
    }

    fun submitAnswer(questionIndex: Int, option: String) {
        val updated = userAnswers.value.toMutableMap()
        updated[questionIndex] = option
        userAnswers.value = updated
    }

    fun toggleBookmark(questionId: Int, isCurrentlyBookmarked: Boolean) {
        viewModelScope.launch {
            repository.updateBookmarkStatus(questionId, !isCurrentlyBookmarked)
            // Refresh bookmarked IDs list
            val bookmarkedList = repository.getBookmarkedQuestionsFlow().first()
            bookmarkedIds.value = bookmarkedList.map { it.id }.toSet()
        }
    }

    fun completePractice() {
        isPracticeTimerActive.value = false
        showPracticeResults.value = true

        // Award points based on performance!
        viewModelScope.launch {
            val correctCount = getCorrectAnswersCount()
            val scoreEarned = correctCount * 20
            val current = repository.getUserProfile()
            if (current != null) {
                repository.updatePoints(current.studentId, current.points + scoreEarned)
                // Add a mock test result
                val result = MockExamResult(
                    examName = "Practice: ${activeSubject.value}",
                    subject = activeSubject.value,
                    score = correctCount,
                    totalQuestions = practiceQuestions.value.size,
                    timeSpentSeconds = practiceTimerSeconds.value,
                    dateString = getCurrentDateString(),
                    rank = 1,
                    performanceFeedback = "Completed successfully. Gained $scoreEarned Points!"
                )
                repository.insertResult(result)
            }
        }
    }

    fun getCorrectAnswersCount(): Int {
        var correct = 0
        practiceQuestions.value.forEachIndexed { index, question ->
            val userAnswer = userAnswers.value[index]
            if (userAnswer == question.correctAnswer) {
                correct++
            }
        }
        return correct
    }

    // --- Mock Exams ---
    fun startMockExam(type: String, subject: String = "Full Suite") {
        mockExamType.value = type
        isMockSubmitted.value = false
        mockTimerSeconds.value = if (type.contains("Timed")) 1800 else 7200
        isMockTimerActive.value = true
        userAnswers.value = emptyMap()
        currentQuestionIndex.value = 0

        viewModelScope.launch {
            val allQs = repository.getAllQuestionsFlow().first()
            val stream = selectedStreamFilter.value.substringBefore(" ")
            val filtered = allQs.filter {
                (it.stream.equals(stream, ignoreCase = true) || it.stream == "Both") &&
                        (subject == "Full Suite" || it.subject.equals(subject, ignoreCase = true))
            }.take(10) // Mock contains 10 comprehensive questions
            practiceQuestions.value = filtered
            navigateTo(Screen.MockCenter)
        }
    }

    fun submitMockExam() {
        isMockTimerActive.value = false
        isMockSubmitted.value = true

        viewModelScope.launch {
            val correctCount = getCorrectAnswersCount()
            val score = correctCount * 10
            val current = repository.getUserProfile()
            if (current != null) {
                repository.updatePoints(current.studentId, current.points + score)
                val startTimer = if (mockExamType.value.contains("Timed")) 1800 else 7200
                val result = MockExamResult(
                    examName = mockExamType.value,
                    subject = "Comprehensive",
                    score = correctCount,
                    totalQuestions = practiceQuestions.value.size,
                    timeSpentSeconds = startTimer - mockTimerSeconds.value,
                    dateString = getCurrentDateString(),
                    rank = (10..150).random(), // simulated ranking
                    performanceFeedback = "Submitted successfully. Great job!"
                )
                repository.insertResult(result)
            }
        }
    }

    // --- Premium Payment & Upgrades ---
    fun submitPaymentVerification(bankName: String, transactionId: String) {
        viewModelScope.launch {
            val current = repository.getUserProfile()
            if (current != null) {
                val newRequest = PremiumRequest(
                    studentId = current.studentId,
                    bankName = bankName,
                    transactionId = transactionId,
                    status = "PENDING",
                    comment = "Payment review pending",
                    submitTime = getCurrentDateString()
                )
                repository.insertRequest(newRequest)
                repository.updatePremiumStatus(current.studentId, "PENDING")
            }
        }
    }

    // --- Offline Caching & Downloads (Premium Exclusive) ---
    fun toggleOfflineDownload(subject: String) {
        viewModelScope.launch {
            val activeProfile = repository.getUserProfile()
            val isPremium = activeProfile?.isPremium == "PREMIUM"
            if (!isPremium) return@launch // Restricted

            val existingDownloads = offlineDownloads.first()
            val isDownloaded = existingDownloads.any { it.title == subject }

            if (isDownloaded) {
                // Delete
                repository.deleteDownload("sub_$subject", subject)
            } else {
                // Download
                val size = (12..45).random().toDouble() / 10.0
                val download = OfflineDownload(
                    contentId = "sub_$subject",
                    title = subject,
                    type = "Subject",
                    sizeMb = size,
                    downloadedAt = getCurrentDateString()
                )
                repository.insertDownload(download)
            }
        }
    }

    fun clearAllOfflineDownloads() {
        viewModelScope.launch {
            repository.clearAllDownloads()
        }
    }

    // --- Admin Operations ---
    fun adminApproveRequest(studentId: String, comment: String) {
        viewModelScope.launch {
            repository.updateRequestStatus(studentId, "PREMIUM", comment)
        }
    }

    fun adminRejectRequest(studentId: String, comment: String) {
        viewModelScope.launch {
            repository.updateRequestStatus(studentId, "REJECTED", comment)
        }
    }

    // Bulk Question Upload System
    fun processBulkUploadFile(filename: String, fileContent: String) {
        // Simulate parsing of xlsx, csv, json, or docx
        val mockParsedQuestions = listOf(
            Question(
                subject = "Aptitude",
                topic = "Visual Reasoning",
                questionText = "Which shape completes the series of 3D cubes rotated 90 degrees?",
                optionA = "Cube A",
                optionB = "Cube B",
                optionC = "Cube C",
                optionD = "Cube D",
                correctAnswer = "C",
                explanation = "Rotating the 3D grid clockwise by 90 degrees aligns with template C.",
                difficulty = "Hard",
                stream = "Both"
            ),
            Question(
                subject = "Mathematics",
                topic = "Matrices",
                questionText = "What is the determinant of a 2x2 identity matrix?",
                optionA = "0",
                optionB = "1",
                optionC = "2",
                optionD = "-1",
                correctAnswer = "B",
                explanation = "det(I) = (1*1) - (0*0) = 1.",
                difficulty = "Easy",
                stream = "Both"
            )
        )
        bulkUploadPreviewList.value = mockParsedQuestions
        bulkUploadStats.value = BulkUploadStats(
            successfullyImported = 850,
            failed = 12,
            duplicates = 5,
            totalRows = 867
        )
    }

    fun importBulkQuestions() {
        viewModelScope.launch {
            repository.insertQuestions(bulkUploadPreviewList.value)
            bulkUploadPreviewList.value = emptyList()
        }
    }

    // --- Sample Data Helpers ---
    private fun generateSampleNotifications() {
        inAppNotifications.value = listOf(
            AppNotification("Study Reminder", "Consistency is key! Solve 10 questions to maintain your 35-day streak.", "10 mins ago", false),
            AppNotification("New Subject Notes", "Grade 12 Physics Electromagnetism Revision Guide is now available.", "2 hours ago", false),
            AppNotification("Mock Exam Alert", "The National Standard Mock Chemistry Exam is starting soon. Enroll now!", "1 day ago", true),
            AppNotification("Premium Updates", "Exclusive Aptitude shortcut videos uploaded. Upgrade to unlock!", "2 days ago", true)
        )
    }

    private fun getCurrentDateString(): String {
        val sdf = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
        return sdf.format(Date())
    }
}

// Data structures
data class AppNotification(
    val title: String,
    val description: String,
    val timeAgo: String,
    val isPremiumOnly: Boolean
)

data class BulkUploadStats(
    val successfullyImported: Int,
    val failed: Int,
    val duplicates: Int,
    val totalRows: Int
)
