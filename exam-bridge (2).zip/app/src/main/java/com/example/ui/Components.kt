package com.example.ui

import com.example.R
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

// ==========================================
// 1. Premium Glassmorphic Cards
// ==========================================

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    isDark: Boolean = true,
    borderColor: Color? = null,
    backgroundColor: Color? = null,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val bg = backgroundColor ?: if (isDark) GlassCardDark else GlassCardLight
    val border = borderColor ?: if (isDark) GlassBorderDark else GlassBorderLight

    val cardModifier = if (onClick != null) {
        modifier.clickable(onClick = onClick)
    } else {
        modifier
    }

    Card(
        modifier = cardModifier,
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = bg),
        border = BorderStroke(1.dp, border),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            content()
        }
    }
}

// ==========================================
// 2. Standard Header (with Hamburger & Theme Toggle)
// ==========================================

@Composable
fun AppHeader(
    title: String,
    onMenuClick: () -> Unit,
    onThemeToggle: () -> Unit,
    isDark: Boolean,
    onBackClick: (() -> Unit)? = null,
    onProfileClick: (() -> Unit)? = null
) {
    val brandGradient = Brush.verticalGradient(
        colors = listOf(
            BrandGradientStart,
            BrandGradientMiddle,
            BrandGradientEnd
        )
    )

    val isHomeHeader = title == "Exam Bridge" && onBackClick == null

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(elevation = 6.dp, clip = false)
            .background(brandGradient)
            .statusBarsPadding()
    ) {
        if (isHomeHeader) {
            // Highly customized, premium Home Header from the Exam Bridge design
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(72.dp)
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Menu (Hamburger) Icon
                IconButton(
                    onClick = onMenuClick,
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "Menu",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // App Logo & Brand Text Column
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Logo Icon (School/Graduation cap or book)
                    Icon(
                        imageVector = Icons.Default.School,
                        contentDescription = null,
                        tint = GoldAccent,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Exam Bridge",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Bridge Your Future Through Success",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Normal
                        )
                    }
                }

                // Theme Toggle Icon
                IconButton(onClick = onThemeToggle) {
                    Icon(
                        imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                        contentDescription = "Toggle Theme",
                        tint = Color.White.copy(alpha = 0.9f)
                    )
                }

                // Notification Bell with Badge
                Box(
                    modifier = Modifier.size(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    IconButton(onClick = { /* Handle Notifications */ }) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notifications",
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    // Red circle badge "3"
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFEF4444))
                            .align(Alignment.TopEnd)
                            .offset(x = (-2).dp, y = 2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "3",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Profile Avatar with green online dot
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .clickable(enabled = onProfileClick != null) { onProfileClick?.invoke() }
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_profile_avatar),
                        contentDescription = "User Profile",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .border(1.5.dp, Color.White, CircleShape)
                    )
                    // Online Dot
                    Box(
                        modifier = Modifier
                            .size(11.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF10B981))
                            .border(1.5.dp, Color.White, CircleShape)
                            .align(Alignment.BottomEnd)
                    )
                }
            }
        } else {
            // Standard Header for other screens
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .padding(horizontal = 8.dp)
            ) {
                // Left Action Button
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                ) {
                    if (onBackClick != null) {
                        IconButton(onClick = onBackClick) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                    } else {
                        IconButton(onClick = onMenuClick) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "Menu",
                                tint = Color.White
                            )
                        }
                    }
                }

                // Centered Title
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(horizontal = 48.dp),
                    textAlign = TextAlign.Center
                )

                // Right Action Button (Theme Toggle)
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                ) {
                    IconButton(onClick = onThemeToggle) {
                        Icon(
                            imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Toggle Theme",
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// 3. Professional Bottom Navigation
// ==========================================

@Composable
fun AppBottomBar(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit,
    isDark: Boolean
) {
    val labels = listOf("Home", "Exams", "UEE", "Notes", "Profile")
    val icons = listOf(
        Icons.Default.Home,
        Icons.Default.Assignment,
        Icons.Default.School,
        Icons.Default.Notes,
        Icons.Default.Person
    )

    val barBgColor = if (isDark) DeepDarkSlate else Color.White
    val inactiveColor = if (isDark) Color.White.copy(alpha = 0.5f) else Color(0xFF9CA3AF)
    val activeGradient = Brush.horizontalGradient(listOf(Color(0xFF2563EB), Color(0xFF3B82F6)))

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 16.dp,
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                clip = false
            )
            .background(
                color = barBgColor,
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
            )
            .border(
                width = 1.dp,
                color = if (isDark) Color.White.copy(alpha = 0.1f) else Color(0xFFD6E4FF),
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
            )
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(68.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            labels.forEachIndexed { index, label ->
                val selected = selectedTab == index
                
                // Animating scale of the icon for smooth feel
                val scale by animateFloatAsState(
                    targetValue = if (selected) 1.15f else 1.0f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessLow
                    ),
                    label = "tab_scale"
                )

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = androidx.compose.material3.ripple(bounded = true, radius = 28.dp),
                            onClick = { onTabSelected(index) }
                        )
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Top Accent Glowing Indicator Line
                    Box(
                        modifier = Modifier
                            .width(36.dp)
                            .height(3.dp)
                            .background(
                                brush = if (selected) {
                                    if (isDark) SolidColor(GoldAccent) else activeGradient
                                } else {
                                    SolidColor(Color.Transparent)
                                },
                                shape = RoundedCornerShape(bottomStart = 2.dp, bottomEnd = 2.dp)
                            )
                    )

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .weight(1f)
                            .graphicsLayer(
                                scaleX = scale,
                                scaleY = scale
                            )
                    ) {
                        if (isDark) {
                            Icon(
                                imageVector = icons[index],
                                contentDescription = label,
                                tint = if (selected) GoldAccent else inactiveColor,
                                modifier = Modifier.size(24.dp)
                            )
                        } else {
                            // Active Tab: Blue gradient using BlendMode.SrcAtop
                            val iconModifier = if (selected) {
                                Modifier
                                    .size(24.dp)
                                    .graphicsLayer(alpha = 0.99f)
                                    .drawWithCache {
                                        onDrawWithContent {
                                            drawContent()
                                            drawRect(activeGradient, blendMode = BlendMode.SrcAtop)
                                        }
                                    }
                            } else {
                                Modifier.size(24.dp)
                            }
                            Icon(
                                imageVector = icons[index],
                                contentDescription = label,
                                tint = if (selected) Color.Unspecified else inactiveColor,
                                modifier = iconModifier
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(2.dp))
                        
                        Text(
                            text = label,
                            style = TextStyle(
                                brush = if (selected) {
                                    if (isDark) SolidColor(GoldAccent) else activeGradient
                                } else {
                                    SolidColor(inactiveColor)
                                }
                            ),
                            fontSize = 11.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// 4. Custom Analytical Charts
// ==========================================

@Composable
fun PerformanceLineChart(isDark: Boolean) {
    val points = listOf(45f, 58f, 72f, 65f, 88f, 92f)
    val color = RoyalBlue
    val gridColor = if (isDark) Color.DarkGray else Color.LightGray

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .padding(16.dp)
    ) {
        val width = size.width
        val height = size.height
        val padding = 20.dp.toPx()

        val stepX = (width - padding * 2) / (points.size - 1)
        val maxVal = 100f
        val minVal = 0f

        // Draw background grid lines
        for (i in 0..4) {
            val y = padding + (height - padding * 2) * i / 4
            drawLine(
                color = gridColor.copy(alpha = 0.3f),
                start = Offset(padding, y),
                end = Offset(width - padding, y),
                strokeWidth = 1.dp.toPx()
            )
        }

        // Draw spline path
        val path = Path()
        points.forEachIndexed { idx, point ->
            val x = padding + idx * stepX
            val ratio = (point - minVal) / (maxVal - minVal)
            val y = height - padding - ratio * (height - padding * 2)

            if (idx == 0) {
                path.moveTo(x, y)
            } else {
                path.lineTo(x, y)
            }

            // Draw data points
            drawCircle(
                color = GoldAccent,
                radius = 5.dp.toPx(),
                center = Offset(x, y)
            )
        }

        drawPath(
            path = path,
            color = color,
            style = Stroke(width = 3.dp.toPx())
        )
    }
}

@Composable
fun MonthlyBarChart(isDark: Boolean) {
    val scores = listOf(75, 82, 90, 85)
    val months = listOf("Mar", "Apr", "May", "Jun")
    val gridColor = if (isDark) Color.DarkGray else Color.LightGray

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.Bottom
        ) {
            scores.forEach { score ->
                val barHeightFraction = score / 100f
                Box(
                    modifier = Modifier
                        .width(36.dp)
                        .fillMaxHeight(barHeightFraction)
                        .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(EmeraldGreen, EmeraldGreen.copy(alpha = 0.5f))
                            )
                        )
                ) {
                    Text(
                        text = "$score%",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 4.dp)
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            months.forEach { month ->
                Text(
                    text = month,
                    color = if (isDark) TextSecondaryDark else TextSecondaryLight,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.width(36.dp)
                )
            }
        }
    }
}

// ==========================================
// 5. Utility Copier Card
// ==========================================

@Composable
fun CopyableInfoItem(
    label: String,
    value: String,
    isDark: Boolean
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .background(
                if (isDark) GlassCardDark else GlassCardLight,
                shape = RoundedCornerShape(12.dp)
            )
            .border(
                1.dp,
                if (isDark) GlassBorderDark else GlassBorderLight,
                shape = RoundedCornerShape(12.dp)
            )
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = label,
                color = if (isDark) TextSecondaryDark else TextSecondaryLight,
                fontSize = 12.sp
            )
            Text(
                text = value,
                color = if (isDark) TextPrimaryDark else TextPrimaryLight,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
        IconButton(
            onClick = {
                clipboardManager.setText(AnnotatedString(value))
                Toast.makeText(context, "$label Copied!", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.size(36.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ContentCopy,
                contentDescription = "Copy",
                tint = GoldAccent,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

// ==========================================
// 8. STREAM-BASED NAVIGATION SELECTOR
// ==========================================
@Composable
fun StreamSelector(
    selectedStream: String,
    onStreamSelected: (String) -> Unit,
    isDark: Boolean
) {
    val streams = listOf(
        Triple("Natural Science", Icons.Default.Science, RoyalBlue),
        Triple("Social Science", Icons.Default.Public, GoldAccent)
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) GlassCardDark else GlassCardLight
        ),
        border = BorderStroke(1.dp, if (isDark) GlassBorderDark else GlassBorderLight)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                streams.forEach { (streamName, icon, activeColor) ->
                    val isSelected = selectedStream == streamName
                    val shortName = when (streamName) {
                        "Natural Science" -> "Natural"
                        else -> "Social"
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (isSelected) activeColor.copy(alpha = 0.15f)
                                else Color.Transparent
                            )
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) activeColor else (if (isDark) Color.DarkGray else Color.LightGray),
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable { onStreamSelected(streamName) }
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = streamName,
                                tint = if (isSelected) activeColor else (if (isDark) Color.Gray else Color.DarkGray),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = shortName,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) activeColor else (if (isDark) Color.White else Color.Black)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    isLoading: Boolean = false,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(if (isPressed && enabled) 0.96f else 1f, label = "button_press_scale")
    val elevation by animateDpAsState(if (isPressed) 1.dp else 4.dp, label = "button_press_elevation")

    val gradient = Brush.horizontalGradient(listOf(Color(0xFF2563EB), Color(0xFF3B82F6)))
    val disabledGradient = Brush.horizontalGradient(listOf(Color.Gray.copy(alpha = 0.4f), Color.LightGray.copy(alpha = 0.4f)))

    Box(
        modifier = modifier
            .scale(scale)
            .shadow(elevation, RoundedCornerShape(20.dp))
            .background(if (enabled) gradient else disabledGradient, RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(color = Color.White.copy(alpha = 0.2f)),
                enabled = enabled && !isLoading,
                onClick = onClick
            )
            .padding(vertical = 14.dp, horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        if (isLoading) {
            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) {
                    Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, letterSpacing = 0.5.sp)
            }
        }
    }
}

@Composable
fun SecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(if (isPressed && enabled) 0.96f else 1f, label = "button_press_scale")
    
    val isDark = isSystemInDarkTheme()
    val bgColor = if (isDark) Color(0xFF1E293B) else Color.White
    val borderColor = if (isDark) Color(0xFF3B82F6).copy(alpha = 0.5f) else Color(0xFF2563EB)
    val tintColor = if (isDark) Color(0xFF60A5FA) else Color(0xFF2563EB)

    Box(
        modifier = modifier
            .scale(scale)
            .background(if (enabled) bgColor else bgColor.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
            .border(1.5.dp, if (enabled) borderColor else borderColor.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(color = tintColor.copy(alpha = 0.15f)),
                enabled = enabled,
                onClick = onClick
            )
            .padding(vertical = 14.dp, horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(
                    imageVector = icon, 
                    contentDescription = null, 
                    tint = if (enabled) tintColor else tintColor.copy(alpha = 0.5f), 
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text, 
                color = if (enabled) tintColor else tintColor.copy(alpha = 0.5f), 
                fontWeight = FontWeight.Bold, 
                fontSize = 15.sp,
                letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
fun PremiumButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(if (isPressed && enabled) 0.96f else 1f, label = "button_press_scale")
    val elevation by animateDpAsState(if (isPressed) 1.dp else 4.dp, label = "button_press_elevation")

    val gradient = Brush.horizontalGradient(listOf(Color(0xFFF59E0B), Color(0xFFFBBF24)))
    
    Box(
        modifier = modifier
            .scale(scale)
            .shadow(elevation, RoundedCornerShape(20.dp))
            .background(gradient, RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(color = Color.White.copy(alpha = 0.2f)),
                enabled = enabled,
                onClick = onClick
            )
            .padding(vertical = 14.dp, horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, letterSpacing = 0.5.sp)
    }
}

