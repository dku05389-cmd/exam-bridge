package com.example.ui

object Translations {
    const val LANG_EN = "English"
    const val LANG_AM = "Amharic"
    const val LANG_OR = "Afaan Oromo"
    const val LANG_TI = "Tigrinya"

    private val translations = mapOf(
        "app_title" to mapOf(
            LANG_EN to "EXAM BRIDGE",
            LANG_AM to "ኤግዛም ብሪጅ",
            LANG_OR to "EXAM BRIDGE",
            LANG_TI to "ኤግዛም ብሪጅ"
        ),
        "tagline" to mapOf(
            LANG_EN to "Bridge Your Future Through Success",
            LANG_AM to "የወደፊት ህይወትዎን በስኬት ያገናኙ",
            LANG_OR to "Fuundurullee keessan Milkiidhaan Wal qabsiisaa",
            LANG_TI to "መፃኢ ሂወትኩም ብዓወት ኣራኽቡ"
        ),
        // Onboarding
        "onb1_title" to mapOf(
            LANG_EN to "Prepare Smarter",
            LANG_AM to "ብልህ ዝግጅት",
            LANG_OR to "Qophii Bilchina Qabu",
            LANG_TI to "ብልህ ምድላው"
        ),
        "onb1_desc" to mapOf(
            LANG_EN to "Access thousands of university entrance exam questions.",
            LANG_AM to "በሺዎች የሚቆጠሩ የዩኒቨርሲቲ መግቢያ ፈተና ጥያቄዎችን ያግኙ።",
            LANG_OR to "Gaaffilee qormaata seensa yuunivarsiitii kumaatama argadhaa.",
            LANG_TI to "ኣሽሓት ናይ ዩኒቨርሲቲ መእተዊ ፈተና ሕቶታት ረኸቡ።"
        ),
        "onb2_title" to mapOf(
            LANG_EN to "Track Progress",
            LANG_AM to "እድገትዎን ይከታተሉ",
            LANG_OR to "Guddina Keessan Hordofaa",
            LANG_TI to "ዕብየትኩም ተኸታተሉ"
        ),
        "onb2_desc" to mapOf(
            LANG_EN to "Monitor your performance with detailed analytics and insights.",
            LANG_AM to "በዝርዝር ትንታኔዎች እና ግንዛቤዎች አፈፃፀምዎን ይከታተሉ።",
            LANG_OR to "Iskoorii keessan hordoffii bal'aadhaan to'adhaa.",
            LANG_TI to "ብዝርዝር ትንታነታትን ርድኢታትን ውፅኢትኩም ተኸታተሉ"
        ),
        "onb3_title" to mapOf(
            LANG_EN to "Achieve Success",
            LANG_AM to "ስኬትን ይቀናጁ",
            LANG_OR to "Milkii Argadhaa",
            LANG_TI to "ዓወት ጨብጡ"
        ),
        "onb3_desc" to mapOf(
            LANG_EN to "Practice, learn and succeed in national university entrance exams.",
            LANG_AM to "በሃገራዊ የዩኒቨርሲቲ መግቢያ ፈተናዎች ይለማመዱ፣ ይማሩ እና ይሳኩ።",
            LANG_OR to "Qormaata biyyaalessaa irratti shaakali, baradhu, milkaa'i.",
            LANG_TI to "ኣብ ሃገራዊ መእተዊ ፈተናታት ተለማመዱ፣ ተማሩ፣ ተዓወቱ።"
        ),
        "get_started" to mapOf(
            LANG_EN to "Get Started",
            LANG_AM to "እንጀምር",
            LANG_OR to "Haa Jalqብኑ",
            LANG_TI to "ንጀምር"
        ),
        "next" to mapOf(
            LANG_EN to "Next",
            LANG_AM to "ቀጣይ",
            LANG_OR to "Itti Aanu",
            LANG_TI to "ቀፃሊ"
        ),
        "back" to mapOf(
            LANG_EN to "Back",
            LANG_AM to "ተመለስ",
            LANG_OR to "Deebi'i",
            LANG_TI to "ተመለስ"
        ),
        "skip" to mapOf(
            LANG_EN to "Skip",
            LANG_AM to "ዘልለው ይለፉ",
            LANG_OR to "Darbii",
            LANG_TI to "ሕለፎ"
        ),
        // Auth
        "login_title" to mapOf(
            LANG_EN to "Welcome Back",
            LANG_AM to "እንኳን ደህና መጡ",
            LANG_OR to "Baga Nagaan Dhuftan",
            LANG_TI to "እንቋዕ ደሓን መፃእኹም"
        ),
        "login_subtitle" to mapOf(
            LANG_EN to "Sign in to continue your success journey",
            LANG_AM to "የስኬት ጉዞዎን ለመቀጠል ይግቡ",
            LANG_OR to "Karaa milkii keessanii itti fufuuf seenuu",
            LANG_TI to "ጉዕዞ ዓወትኩም ንምቕጻል እተዉ"
        ),
        "email" to mapOf(
            LANG_EN to "Email Address",
            LANG_AM to "ኢሜል አድራሻ",
            LANG_OR to "Teessoo Imeelii",
            LANG_TI to "ኢሜል ኣድራሻ"
        ),
        "password" to mapOf(
            LANG_EN to "Password",
            LANG_AM to "የይለፍ ቃል",
            LANG_OR to "Jecha Darbiiti",
            LANG_TI to "ሚስጢራዊ ቃል"
        ),
        "show_password" to mapOf(
            LANG_EN to "Show Password",
            LANG_AM to "የይለፍ ቃል አሳይ",
            LANG_OR to "Jecha Darbiiti Agarsiisi",
            LANG_TI to "ሚስጢራዊ ቃል አርእይ"
        ),
        "remember_me" to mapOf(
            LANG_EN to "Remember Me",
            LANG_AM to "አስታውሰኝ",
            LANG_OR to "Na Yaadadhu",
            LANG_TI to "ዝክረኒ"
        ),
        "forgot_password" to mapOf(
            LANG_EN to "Forgot Password?",
            LANG_AM to "የይለፍ ቃል ረሱ?",
            LANG_OR to "Jecha Darbiiti Dagattanii?",
            LANG_TI to "ሚስጢራዊ ቃል ረሲዕኩም?"
        ),
        "login_btn" to mapOf(
            LANG_EN to "Log In",
            LANG_AM to "ግባ",
            LANG_OR to "Seeni",
            LANG_TI to "እቶ"
        ),
        "register_prompt" to mapOf(
            LANG_EN to "Don't have an account? Register",
            LANG_AM to "አካውንት የለዎትም? ይመዝገቡ",
            LANG_OR to "Akaawuntii hin qabdan? Galmaa'aa",
            LANG_TI to "አካውንት የብልኩምን? ይተመዝገቡ"
        ),
        "register_title" to mapOf(
            LANG_EN to "Create Account",
            LANG_AM to "አዲስ አካውንት መፍጠሪያ",
            LANG_OR to "Akaawuntii Uumi",
            LANG_TI to "ሓዱሽ አካውንት ፍጠር"
        ),
        "register_subtitle" to mapOf(
            LANG_EN to "Enter details to start your preparation",
            LANG_AM to "ዝግጅትዎን ለመጀመር ዝርዝሮችን ያስገቡ",
            LANG_OR to "Qophii jalqabuuf ibsa galchaa",
            LANG_TI to "ምድላውኩም ንምጅማር ዝርዝር ሓበሬታ የእትዉ"
        ),
        "full_name" to mapOf(
            LANG_EN to "Full Name",
            LANG_AM to "ሙሉ ስም",
            LANG_OR to "Maqaa Guutuu",
            LANG_TI to "ምሉእ ስም"
        ),
        "school" to mapOf(
            LANG_EN to "School Name",
            LANG_AM to "የትምህርት ቤት ስም",
            LANG_OR to "Maqaa Mana Barumsaa",
            LANG_TI to "ሽም ቤት ትምህርቲ"
        ),
        "phone" to mapOf(
            LANG_EN to "Phone Number",
            LANG_AM to "ስልክ ቁጥር",
            LANG_OR to "Lakkoofsa Bilbilaa",
            LANG_TI to "ቁፅሪ ስልኪ"
        ),
        "register_btn" to mapOf(
            LANG_EN to "Register Now",
            LANG_AM to "አሁን ይመዝገቡ",
            LANG_OR to "Amma Galmaa'i",
            LANG_TI to "ሕጂ ይተመዝገቡ"
        ),
        "login_prompt" to mapOf(
            LANG_EN to "Already have an account? Log In",
            LANG_AM to "አካውንት አለዎት? ይግቡ",
            LANG_OR to "Duraan akaawuntii qabdu? Seenaa",
            LANG_TI to "ቅድም ክብል አካውንት ኣለኩም? እተዉ"
        ),
        // Stream Selection
        "stream_title" to mapOf(
            LANG_EN to "Choose Your Academic Stream",
            LANG_AM to "የትምህርት ዘርፍዎን ይምረጡ",
            LANG_OR to "Damee Barnootaa Keessan Filadhaa",
            LANG_TI to "ዓይነት ትምህርትኹም ይምረጡ"
        ),
        "stream_desc" to mapOf(
            LANG_EN to "This selection is permanent. You can change it later only from settings.",
            LANG_AM to "ይህ ምርጫ ቋሚ ነው። በኋላ ላይ ከቅንብሮች ውስጥ ብቻ ነው መለወጥ የሚቻለው።",
            LANG_OR to "Filannoon kun dhaabbataadha. Booda qindaa'ina keessaa qofa jijjiiruu dandeessu.",
            LANG_TI to "እዚ ምርጫ እዚ ቀዋሚ እዩ። ፀኒሕኩም ካብ ቅንብራት ጥራሕ ኢኹም ክትቅይሩዎ ትኽእሉ።"
        ),
        "natural_science" to mapOf(
            LANG_EN to "Natural Science",
            LANG_AM to "የተፈጥሮ ሳይንስ",
            LANG_OR to "Saayinsii Samamaa",
            LANG_TI to "ተፈጥሮ ሳይንስ"
        ),
        "social_science" to mapOf(
            LANG_EN to "Social Science",
            LANG_AM to "የማህበራዊ ሳይንስ",
            LANG_OR to "Saayinsii Hawaasummaa",
            LANG_TI to "ማሕበራዊ ሳይንስ"
        ),
        "continue" to mapOf(
            LANG_EN to "Continue",
            LANG_AM to "ቀጥል",
            LANG_OR to "Itti Fufi",
            LANG_TI to "ቀጽል"
        ),
        // Home
        "welcome_back" to mapOf(
            LANG_EN to "Welcome back,",
            LANG_AM to "እንኳን ደህና መጡ፣",
            LANG_OR to "Baga nagaan deebitan,",
            LANG_TI to "እንቋዕ ደሓን መፃእኹም፣"
        ),
        "daily_goal" to mapOf(
            LANG_EN to "Daily Goal",
            LANG_AM to "የቀን ግብ",
            LANG_OR to "Galma Guyyaa",
            LANG_TI to "ዕለታዊ ግብ"
        ),
        "study_streak" to mapOf(
            LANG_EN to "Study Streak",
            LANG_AM to "የትምህርት ተከታታይነት",
            LANG_OR to "Torbee Barumsaa",
            LANG_TI to "ተኸታታሊ መዓልታት"
        ),
        "days" to mapOf(
            LANG_EN to "Days",
            LANG_AM to "ቀናት",
            LANG_OR to "Guyyoota",
            LANG_TI to "መዓልታት"
        ),
        "hours" to mapOf(
            LANG_EN to "Hours",
            LANG_AM to "ሰዓታት",
            LANG_OR to "Sa'aatii",
            LANG_TI to "ሰዓታት"
        ),
        // Actions
        "practice" to mapOf(
            LANG_EN to "Practice",
            LANG_AM to "ልምምድ",
            LANG_OR to "Shaakala",
            LANG_TI to "ተለማመድ"
        ),
        "mock_exams" to mapOf(
            LANG_EN to "Mock Exams",
            LANG_AM to "የሙከራ ፈተናዎች",
            LANG_OR to "Qormaata Mokkii",
            LANG_TI to "ሙከራ ፈተናታት"
        ),
        "analytics" to mapOf(
            LANG_EN to "Analytics",
            LANG_AM to "ትንታኔዎች",
            LANG_OR to "Xiinxala",
            LANG_TI to "ትንታነታት"
        ),
        "notes" to mapOf(
            LANG_EN to "Notes",
            LANG_AM to "ማስታወሻዎች",
            LANG_OR to "Yaadannoo",
            LANG_TI to "ማስታወሻታት"
        ),
        "video_lessons" to mapOf(
            LANG_EN to "Video Lessons",
            LANG_AM to "የቪዲዮ ትምህርቶች",
            LANG_OR to "Barnoota Viidiyoo",
            LANG_TI to "ትምህርትታት ቪዲዮ"
        ),
        "leaderboard" to mapOf(
            LANG_EN to "Leaderboard",
            LANG_AM to "ደረጃ ሰሌዳ",
            LANG_OR to "Gubbaa",
            LANG_TI to "መሰላል ዓወት"
        ),
        "premium" to mapOf(
            LANG_EN to "Premium",
            LANG_AM to "ፕሪሚየም",
            LANG_OR to "Pirimiyamii",
            LANG_TI to "ፕሪሚየም"
        ),
        "settings" to mapOf(
            LANG_EN to "Settings",
            LANG_AM to "ቅንብሮች",
            LANG_OR to "Qindaa'ina",
            LANG_TI to "ቅንብራት"
        ),
        "profile" to mapOf(
            LANG_EN to "Profile",
            LANG_AM to "ፕሮፋይል",
            LANG_OR to "Ibsa Namummaa",
            LANG_TI to "ፕሮፋይል"
        ),
        // Premium upgrade
        "upgrade_benefit_title" to mapOf(
            LANG_EN to "Upgrade to Premium",
            LANG_AM to "ወደ ፕሪሚየም ያሳድጉ",
            LANG_OR to "Gara Pirimiyamiitti Ol Guddisi",
            LANG_TI to "ናብ ፕሪሚየም ክብ የብሉ"
        ),
        "go_to_payment" to mapOf(
            LANG_EN to "Go To Payment",
            LANG_AM to "ወደ ክፍያ ይሂዱ",
            LANG_OR to "Gara Kafaltiitti Darbi",
            LANG_TI to "ናብ ክፍሊት ይኺዱ"
        ),
        "payment_title" to mapOf(
            LANG_EN to "Secure Payment Portal",
            LANG_AM to "አስተማማኝ የክፍያ ፖርታል",
            LANG_OR to "Kafaltii Nageenya Qabu",
            LANG_TI to "ውሑስ ናይ ክፍሊት ማእከል"
        ),
        "offline_download" to mapOf(
            LANG_EN to "Download for Offline Use",
            LANG_AM to "ያለ ኢንተርኔት ለመጠቀም ያውርዱ",
            LANG_OR to "Inshuraansii malee buufadhaa",
            LANG_TI to "ብዘይ ኢንተርኔት ንምጥቓም የውርዱ"
        ),
        "offline_indicator" to mapOf(
            LANG_EN to "You are studying offline content.",
            LANG_AM to "ከኢንተርኔት ውጪ የወረዱ ይዘቶችን እያጠኑ ነው።",
            LANG_OR to "Kontentii buufame shaakalaa jirtu.",
            LANG_TI to "ብዘይ መስመር ዝወረዱ ትሕዝቶታት የፅንዑ ኣለዉ።"
        ),
        "connected" to mapOf(
            LANG_EN to "Connected",
            LANG_AM to "የተገናኘ",
            LANG_OR to "Walitti Hidhadhe",
            LANG_TI to "ተኣሳሲሩ"
        ),
        "offline" to mapOf(
            LANG_EN to "Offline Mode",
            LANG_AM to "ከመስመር ውጭ",
            LANG_OR to "Hojii Malee",
            LANG_TI to "ብዘይ መስመር"
        ),
        "submit_verification" to mapOf(
            LANG_EN to "Submit Verification",
            LANG_AM to "ማረጋገጫ አስገባ",
            LANG_OR to "Mirkaneessa Galchi",
            LANG_TI to "መረጋገፂ የእትዉ"
        ),
        "tx_id" to mapOf(
            LANG_EN to "Transaction ID",
            LANG_AM to "የግብይት መለያ ቁጥር (Tx ID)",
            LANG_OR to "Lakk. Daddarbaa (Tx ID)",
            LANG_TI to "ቁፅሪ መለለዪ ትራንዛክሽን"
        ),
        "pending_message" to mapOf(
            LANG_EN to "Verification Submitted Successfully. Payment review will be completed within 12 hours. Please wait patiently.",
            LANG_AM to "ማረጋገጫው በተሳካ ሁኔታ ገብቷል። የክፍያ ግምገማው በ12 ሰዓታት ውስጥ ይጠናቀቃል። እባክዎን በትዕግስት ይጠብቁ።",
            LANG_OR to "Mirkaneessi milkiidhaan galmeeffameera. To'annoon kafaltii sa'aatii 12 keessatti xumurama. Obsaan eegaa.",
            LANG_TI to "መረጋገፂ ብዓወት ተፈኒኑ ኣሎ። ገምጋም ክፍሊት ኣብ ውሽጢ 12 ሰዓታት ክዛዘም እዩ። ብዕግስት ይፅበዩ።"
        ),
        "about_us" to mapOf(
            LANG_EN to "About Us",
            LANG_AM to "ስለ እኛ",
            LANG_OR to "Waa'ee Keenya",
            LANG_TI to "ብዛዕባና"
        ),
        "rate_app" to mapOf(
            LANG_EN to "Rate App",
            LANG_AM to "መተግበሪያውን ደረጃ ይስጡ",
            LANG_OR to "Appii Mirkaneessi",
            LANG_TI to "ነዚ መተግበሪ ገምግሙ"
        ),
        "logout" to mapOf(
            LANG_EN to "Logout",
            LANG_AM to "ውጣ",
            LANG_OR to "Ba'i",
            LANG_TI to "ውጻእ"
        )
    )

    fun get(key: String, lang: String): String {
        return translations[key]?.get(lang) ?: translations[key]?.get(LANG_EN) ?: key
    }
}
