package com.example.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// High-fidelity styling tokens
private val ThemeBlue = Color(0xFF2563EB)
private val ThemeGold = Color(0xFFF59E0B)
private val ThemeSuccess = Color(0xFF10B981)
private val DarkBackground = Color(0xFF0F172A)
private val LightBackground = Color(0xFFF1F5F9)

@Composable
fun PremiumUpgradeScreen(
    viewModel: ExamBridgeViewModel,
    profile: UserProfile,
    isDark: Boolean
) {
    val reqState by viewModel.premiumRequest.collectAsState(initial = null)
    var step by remember { mutableIntStateOf(1) }
    var selectedMethod by remember { mutableStateOf("Commercial Bank of Ethiopia") }
    var txIdInput by remember { mutableStateOf("") }
    
    // Receipt simulation states
    var uploadedFileName by remember { mutableStateOf<String?>(null) }
    
    val context = LocalContext.current

    LaunchedEffect(reqState) {
        if (reqState != null) {
            step = 4
        }
    }

    val topBarTitle = when (step) {
        1 -> "Payment Method"
        2 -> "Payment Details"
        3 -> "Payment Verification"
        else -> "Verification Submitted"
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = topBarTitle,
                onMenuClick = {},
                onThemeToggle = {},
                isDark = isDark,
                onBackClick = {
                    if (step > 1 && step < 4) step-- else viewModel.navigateBack()
                }
            )
        },
        containerColor = if (isDark) DarkBackground else LightBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Flow Header (PAYMENT METHOD FLOW vs AFTER SUBMISSION)
            if (step < 4) {
                FlowHeader(title = "PAYMENT METHOD FLOW", isDark = isDark)
                PaymentStepIndicator(currentStep = step, isDark = isDark)
            } else {
                FlowHeader(title = "AFTER SUBMISSION", isDark = isDark)
            }

            Spacer(modifier = Modifier.height(12.dp))

            when (step) {
                1 -> Step1ChooseMethod(
                    isDark = isDark,
                    onMethodSelected = { method ->
                        selectedMethod = method
                        step = 2
                    }
                )
                2 -> Step2PaymentDetails(
                    isDark = isDark,
                    method = selectedMethod,
                    onNext = { step = 3 },
                    onBack = { step = 1 }
                )
                3 -> Step3Verification(
                    isDark = isDark,
                    method = selectedMethod,
                    txId = txIdInput,
                    onTxIdChange = { txIdInput = it },
                    uploadedFileName = uploadedFileName,
                    onUploadedFileChange = { uploadedFileName = it },
                    onSubmit = {
                        if (txIdInput.isBlank()) {
                            Toast.makeText(context, "Please enter your Transaction ID", Toast.LENGTH_LONG).show()
                        } else if (uploadedFileName == null) {
                            Toast.makeText(context, "Please upload a payment receipt", Toast.LENGTH_LONG).show()
                        } else {
                            viewModel.submitPaymentVerification(selectedMethod, txIdInput)
                            Toast.makeText(context, "Verification Submitted Successfully!", Toast.LENGTH_SHORT).show()
                            step = 4
                        }
                    }
                )
                4 -> Step4Success(
                    isDark = isDark,
                    method = selectedMethod,
                    status = reqState?.status ?: "Pending Review",
                    amount = "Br 1,500.00",
                    onBackToHome = { viewModel.navigateTo(Screen.Dashboard) }
                )
            }
        }
    }
}

@Composable
fun FlowHeader(title: String, isDark: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp, bottom = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .width(48.dp)
                .height(1.dp)
                .background(if (isDark) Color.White.copy(alpha = 0.2f) else Color.Black.copy(alpha = 0.15f))
        )
        Text(
            text = "  $title  ",
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold,
            color = if (isDark) Color.White.copy(alpha = 0.7f) else Color.Black.copy(alpha = 0.6f),
            letterSpacing = 2.sp,
            textAlign = TextAlign.Center
        )
        Box(
            modifier = Modifier
                .width(48.dp)
                .height(1.dp)
                .background(if (isDark) Color.White.copy(alpha = 0.2f) else Color.Black.copy(alpha = 0.15f))
        )
    }
}

@Composable
fun PaymentStepIndicator(currentStep: Int, isDark: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Step 1
        StepIndicatorItem(
            stepNumber = 1,
            title = "STEP 1",
            label = "Choose Payment Method",
            isActive = currentStep >= 1,
            isCurrent = currentStep == 1,
            isDark = isDark
        )
        
        // Connector 1 -> 2
        Box(
            modifier = Modifier
                .width(28.dp)
                .height(1.dp)
                .background(if (currentStep >= 2) ThemeBlue else (if (isDark) Color(0xFF334155) else Color(0xFFCBD5E1)))
                .padding(horizontal = 4.dp)
        )

        // Step 2
        StepIndicatorItem(
            stepNumber = 2,
            title = "STEP 2",
            label = "Payment Details",
            isActive = currentStep >= 2,
            isCurrent = currentStep == 2,
            isDark = isDark
        )

        // Connector 2 -> 3
        Box(
            modifier = Modifier
                .width(28.dp)
                .height(1.dp)
                .background(if (currentStep >= 3) ThemeBlue else (if (isDark) Color(0xFF334155) else Color(0xFFCBD5E1)))
                .padding(horizontal = 4.dp)
        )

        // Step 3
        StepIndicatorItem(
            stepNumber = 3,
            title = "STEP 3",
            label = "Verification",
            isActive = currentStep >= 3,
            isCurrent = currentStep == 3,
            isDark = isDark
        )
    }
}

@Composable
fun StepIndicatorItem(
    stepNumber: Int,
    title: String,
    label: String,
    isActive: Boolean,
    isCurrent: Boolean,
    isDark: Boolean
) {
    val activeColor = ThemeBlue
    val inactiveColor = if (isDark) Color(0xFF1E293B) else Color(0xFFE2E8F0)
    val circleBg = if (isActive) activeColor else inactiveColor
    val textColor = if (isActive) (if (isDark) Color.White else Color(0xFF1E293B)) else Color.Gray

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(circleBg),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = stepNumber.toString(),
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Column {
            Text(
                text = title,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = if (isCurrent) ThemeBlue else Color.Gray
            )
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                color = textColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun BankIconWidget(bankName: String) {
    val (bgColor, iconTint, character) = when {
        bankName.contains("Commercial Bank") -> Triple(Color(0xFF5E3A10), Color(0xFFFCD34D), "C")
        bankName.contains("Abay") -> Triple(Color(0xFF047857), Color.White, "A")
        bankName.contains("Abyssinia") -> Triple(Color(0xFFD97706), Color.White, "A")
        bankName.contains("Awash") -> Triple(Color(0xFF1E3A8A), Color.White, "A")
        bankName.contains("CBE Birr") -> Triple(Color(0xFF15803D), Color.White, "B")
        bankName.contains("Telebirr") -> Triple(Color(0xFF0284C7), Color.White, "T")
        else -> Triple(Color(0xFF475569), Color.White, "B")
    }

    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor),
        contentAlignment = Alignment.Center
    ) {
        when {
            bankName.contains("Commercial Bank") -> {
                Icon(Icons.Default.AccountBalance, contentDescription = null, tint = iconTint, modifier = Modifier.size(24.dp))
            }
            bankName.contains("Abay") -> {
                Icon(Icons.Default.Spa, contentDescription = null, tint = iconTint, modifier = Modifier.size(24.dp))
            }
            bankName.contains("Abyssinia") -> {
                Icon(Icons.Default.Star, contentDescription = null, tint = iconTint, modifier = Modifier.size(24.dp))
            }
            bankName.contains("Awash") -> {
                Icon(Icons.Default.Waves, contentDescription = null, tint = iconTint, modifier = Modifier.size(24.dp))
            }
            bankName.contains("CBE Birr") -> {
                Text("Birr", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            bankName.contains("Telebirr") -> {
                Text("tele", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
            }
            else -> {
                Text(character, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}

@Composable
fun Step1ChooseMethod(isDark: Boolean, onMethodSelected: (String) -> Unit) {
    val cardBg = if (isDark) Color(0xFF1E293B) else Color.White
    val borderColor = if (isDark) Color.White.copy(alpha = 0.08f) else Color(0xFFE2E8F0)
    val textColor = if (isDark) Color.White else Color(0xFF1E293B)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Plan Overview Card (Styled exactly like Step 1 top element)
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = cardBg),
            border = BorderStroke(1.dp, borderColor),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(ThemeBlue.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Diamond, contentDescription = "Premium Icon", tint = ThemeBlue, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Commercial Bank",
                            color = textColor,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .background(ThemeGold, shape = RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "BEST VALUE",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = borderColor.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarToday, contentDescription = "Duration", tint = Color.Gray, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Duration", color = Color.Gray, fontSize = 13.sp)
                    }
                    Text("385 Days", color = textColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Sell, contentDescription = "Price", tint = Color.Gray, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Price", color = Color.Gray, fontSize = 13.sp)
                    }
                    Text("Br 1,500.00", color = ThemeGold, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                }
            }
        }
        
        // Choose Payment Method Text
        Column(modifier = Modifier.padding(horizontal = 4.dp)) {
            Text(
                text = "Choose Payment Method",
                color = textColor,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Select your preferred payment option below",
                color = Color.Gray,
                fontSize = 12.sp
            )
        }
        
        val methods = listOf(
            "Commercial Bank of Ethiopia" to "CBE",
            "Abay Bank" to "Abay",
            "Abyssinia Bank" to "BoA",
            "Awash Bank" to "Awash",
            "CBE Birr" to "CBE Birr",
            "Telebirr" to "Telebirr"
        )
        
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            methods.forEach { (name, subtitle) ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    border = BorderStroke(1.dp, borderColor),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onMethodSelected(name) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BankIconWidget(bankName = name)
                        
                        Spacer(modifier = Modifier.width(16.dp))
                        
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = name,
                                color = textColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            if (subtitle.isNotEmpty()) {
                                Text(
                                    text = subtitle,
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                            }
                        }
                        
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "Select",
                            tint = Color.Gray,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Lock, contentDescription = "Secure", tint = ThemeGold, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Secure & Encrypted Payment Flow", color = Color.Gray, fontSize = 12.sp)
        }
        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun Step2PaymentDetails(
    isDark: Boolean,
    method: String,
    onNext: () -> Unit,
    onBack: () -> Unit
) {
    val cardBg = if (isDark) Color(0xFF1E293B) else Color.White
    val borderColor = if (isDark) Color.White.copy(alpha = 0.08f) else Color(0xFFE2E8F0)
    val textColor = if (isDark) Color.White else Color(0xFF1E293B)
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current
    
    val copyAction = { text: String, label: String ->
        clipboardManager.setText(AnnotatedString(text))
        Toast.makeText(context, "$label Copied!", Toast.LENGTH_SHORT).show()
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Secure indicator header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(ThemeSuccess.copy(alpha = 0.12f))
                .border(1.dp, ThemeSuccess.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, contentDescription = "Verified Secure", tint = ThemeSuccess, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("You are paying securely", color = ThemeSuccess, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Your payment information is fully encrypted.", color = if (isDark) Color.LightGray else Color(0xFF475569), fontSize = 11.sp)
                }
            }
        }

        // Details Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = cardBg),
            border = BorderStroke(1.dp, borderColor),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Bank logo header
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BankIconWidget(bankName = method)
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(method, color = textColor, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        Text(if (method.contains("CBE") || method.contains("Commercial")) "CBE" else method, color = Color.Gray, fontSize = 12.sp)
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Please transfer the exact amount to the account below",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                
                DetailRowWidget(label = "Account Name", value = "Exam Bridge", textColor = textColor)
                Spacer(modifier = Modifier.height(10.dp))
                Divider(color = borderColor.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(10.dp))
                
                DetailRowWidget(
                    label = "Account Number",
                    value = "1000 1234 5678901",
                    textColor = textColor,
                    onCopy = { copyAction("100012345678901", "Account Number") }
                )
                Spacer(modifier = Modifier.height(10.dp))
                Divider(color = borderColor.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(10.dp))
                
                DetailRowWidget(
                    label = "Branch",
                    value = "Main Branch",
                    textColor = textColor,
                    onCopy = { copyAction("Main Branch", "Branch Name") }
                )
                Spacer(modifier = Modifier.height(10.dp))
                Divider(color = borderColor.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(10.dp))
                
                DetailRowWidget(
                    label = "Amount",
                    value = "Br 1,500.00",
                    isAmount = true,
                    textColor = textColor,
                    onCopy = { copyAction("1500", "Amount") }
                )
                
                Spacer(modifier = Modifier.height(20.dp))
                
                // Blue Card info
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(ThemeBlue.copy(alpha = 0.15f))
                        .border(1.dp, ThemeBlue.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Row {
                        Icon(Icons.Default.Info, contentDescription = "Transfer warning info", tint = ThemeBlue, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Please double check the account number and transfer exactly Br 1,500.00. Keep your transaction receipt to upload in the next step.",
                            color = if (isDark) Color(0xFF93C5FD) else Color(0xFF1E40AF),
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }

        // How to Pay Instructions Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = cardBg),
            border = BorderStroke(1.dp, borderColor),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "How to Pay",
                    color = textColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                
                val paymentInstructions = listOf(
                    "Copy the bank account details shown above.",
                    "Log into your mobile banking app or go to nearest branch.",
                    "Transfer the exact amount of Br 1,500.00.",
                    "Capture a screenshot or save the bank transfer receipt.",
                    "Click the button below to submit your receipt & Transaction ID."
                )
                
                paymentInstructions.forEachIndexed { index, instruction ->
                    Row(modifier = Modifier.padding(vertical = 4.dp)) {
                        Text(
                            text = "${index + 1}. ",
                            color = ThemeBlue,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.width(20.dp)
                        )
                        Text(
                            text = instruction,
                            color = if (isDark) Color.LightGray else Color(0xFF475569),
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Large Premium Navigation Button
        Button(
            onClick = onNext,
            colors = ButtonDefaults.buttonColors(containerColor = ThemeBlue),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.ChevronLeft, contentDescription = "Go back step", tint = Color.White)
                Text(
                    text = "I Have Made the Payment",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Icon(Icons.Default.ChevronRight, contentDescription = "Go next step", tint = Color.White)
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun DetailRowWidget(
    label: String,
    value: String,
    isAmount: Boolean = false,
    textColor: Color,
    onCopy: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.Gray, fontSize = 12.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = value,
                color = if (isAmount) ThemeGold else textColor,
                fontWeight = if (isAmount) FontWeight.ExtraBold else FontWeight.Bold,
                fontSize = if (isAmount) 16.sp else 13.sp
            )
            if (onCopy != null) {
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(if (textColor == Color.White) Color.White.copy(alpha = 0.1f) else Color.Black.copy(alpha = 0.05f))
                        .clickable { onCopy() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy detail",
                        tint = Color.Gray,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun Step3Verification(
    isDark: Boolean,
    method: String,
    txId: String,
    onTxIdChange: (String) -> Unit,
    uploadedFileName: String?,
    onUploadedFileChange: (String?) -> Unit,
    onSubmit: () -> Unit
) {
    val cardBg = if (isDark) Color(0xFF1E293B) else Color.White
    val borderColor = if (isDark) Color.White.copy(alpha = 0.08f) else Color(0xFFE2E8F0)
    val textColor = if (isDark) Color.White else Color(0xFF1E293B)
    
    // Simulating file uploading
    var isUploading by remember { mutableStateOf(false) }
    var uploadProgress by remember { mutableFloatStateOf(0f) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(isUploading) {
        if (isUploading) {
            uploadProgress = 0f
            while (uploadProgress < 1f) {
                delay(150)
                uploadProgress += 0.2f
            }
            isUploading = false
            onUploadedFileChange("receipt_${method.lowercase().replace(" ", "_")}_payment.jpg")
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Summary Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = cardBg),
            border = BorderStroke(1.dp, borderColor),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BankIconWidget(bankName = method)
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(method, color = textColor, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(if (method.contains("CBE") || method.contains("Commercial")) "CBE" else method, color = Color.Gray, fontSize = 12.sp)
                    }
                }
                
                Spacer(modifier = Modifier.height(14.dp))
                Divider(color = borderColor.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(14.dp))
                
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Amount to Pay", color = Color.Gray, fontSize = 13.sp)
                    Text("Br 1,500.00", color = ThemeGold, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                }
            }
        }
        
        // Form Title
        Column(modifier = Modifier.padding(horizontal = 4.dp)) {
            Text("Enter Payment Details", color = textColor, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text("Please provide your payment information to verify your transaction", color = Color.Gray, fontSize = 12.sp)
        }
        
        // Transaction ID Input Field
        Column {
            Text("Transaction ID", color = textColor, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = txId,
                onValueChange = onTxIdChange,
                placeholder = { Text("Enter transaction ID (e.g. FT2623...)", color = Color.Gray, fontSize = 13.sp) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ThemeBlue,
                    unfocusedBorderColor = borderColor,
                    focusedContainerColor = cardBg,
                    unfocusedContainerColor = cardBg,
                    focusedTextColor = textColor,
                    unfocusedTextColor = textColor
                ),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text("Enter the unique transaction reference ID from your transfer confirmation.", color = Color.Gray, fontSize = 11.sp)
        }
        
        // Interactive Receipt Upload Widget
        Column {
            Text("Upload Payment Receipt", color = textColor, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(6.dp))
            
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (isDark) Color(0xFF1E293B) else Color(0xFFF8FAFC))
                    .border(1.dp, borderColor, shape = RoundedCornerShape(16.dp))
                    .clickable {
                        if (!isUploading && uploadedFileName == null) {
                            isUploading = true
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                if (isUploading) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = ThemeBlue, modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Uploading Simulated Receipt...", color = ThemeBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("${(uploadProgress * 100).toInt()}% completed", color = Color.Gray, fontSize = 11.sp)
                    }
                } else if (uploadedFileName != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(ThemeSuccess.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Check, contentDescription = "Success Upload", tint = ThemeSuccess, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = uploadedFileName,
                                    color = textColor,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text("Uploaded successfully (1.4 MB)", color = Color.Gray, fontSize = 11.sp)
                            }
                        }
                        IconButton(onClick = { onUploadedFileChange(null) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete simulated file", tint = Color.Red, modifier = Modifier.size(20.dp))
                        }
                    }
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.CloudUpload, contentDescription = "Upload Receipt", tint = ThemeBlue, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Tap to simulate receipt upload", color = ThemeBlue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("PNG, JPG or PDF format (Max 5MB)", color = Color.Gray, fontSize = 11.sp)
                    }
                }
            }
        }
        
        // Guidelines / Instructions Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = if (isDark) Color(0xFF0F172A) else Color(0xFFF1F5F9)),
            border = BorderStroke(1.dp, borderColor),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = "Note details", tint = ThemeBlue, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Important Instructions", color = textColor, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Spacer(modifier = Modifier.height(10.dp))
                val notes = listOf(
                    "Ensure the receipt image is clear and fully readable.",
                    "The transaction ID must match exactly with the bank reference.",
                    "Verification normally completes in under 12 hours."
                )
                notes.forEach { text ->
                    Row(modifier = Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(4.dp).background(Color.Gray, shape = CircleShape))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text, color = Color.Gray, fontSize = 11.sp)
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(12.dp))
        
        // Submit Button
        Button(
            onClick = onSubmit,
            colors = ButtonDefaults.buttonColors(containerColor = ThemeBlue),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Check, contentDescription = "Submit verification check", tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Submit Verification", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Lock, contentDescription = "Secure lock icon", tint = ThemeGold, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Your billing information is 100% secure", color = Color.Gray, fontSize = 12.sp)
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun Step4Success(
    isDark: Boolean,
    method: String,
    status: String,
    amount: String,
    onBackToHome: () -> Unit
) {
    val cardBg = if (isDark) Color(0xFF1E293B) else Color.White
    val borderColor = if (isDark) Color.White.copy(alpha = 0.08f) else Color(0xFFE2E8F0)
    val textColor = if (isDark) Color.White else Color(0xFF1E293B)

    val formatter = SimpleDateFormat("MMMM dd, yyyy hh:mm a", Locale.getDefault())
    val formattedDate = remember { formatter.format(Date()) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        
        // Centered animated card with checklist & success status
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = cardBg),
            border = BorderStroke(1.dp, borderColor),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier.size(80.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(ThemeSuccess.copy(alpha = 0.15f))
                    )
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Success check icon",
                        tint = ThemeSuccess,
                        modifier = Modifier.size(56.dp)
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Verification Submitted Successfully!",
                    color = ThemeSuccess,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Your payment verification form has been received. Our team will verify your payment details and activate your premium status within 12 hours.",
                    color = Color.Gray,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )
            }
        }
        
        // Status & Details Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = cardBg),
            border = BorderStroke(1.dp, borderColor),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Status Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Status", color = Color.Gray, fontSize = 13.sp)
                    Box(
                        modifier = Modifier
                            .background(ThemeGold.copy(alpha = 0.15f), shape = RoundedCornerShape(12.dp))
                            .border(1.dp, ThemeGold, shape = RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = status,
                            color = ThemeGold,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 11.sp
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(14.dp))
                Divider(color = borderColor.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(14.dp))
                
                // Submitted On Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Submitted On", color = Color.Gray, fontSize = 13.sp)
                    Text(text = formattedDate, color = textColor, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                
                Spacer(modifier = Modifier.height(14.dp))
                Divider(color = borderColor.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(14.dp))
                
                // Payment Method Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Payment Method", color = Color.Gray, fontSize = 13.sp)
                    Text(text = method, color = textColor, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                
                Spacer(modifier = Modifier.height(14.dp))
                Divider(color = borderColor.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(14.dp))
                
                // Amount Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Amount", color = Color.Gray, fontSize = 13.sp)
                    Text(text = amount, color = textColor, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Back to Home Button
        Button(
            onClick = onBackToHome,
            colors = ButtonDefaults.buttonColors(containerColor = ThemeBlue),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Home, contentDescription = "Return home icon", tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Back to Home",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }
        Spacer(modifier = Modifier.height(32.dp))
    }
}
